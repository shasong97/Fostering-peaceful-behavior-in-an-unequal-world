clc; clear; close all;

%% ============================================================
% Parameter domain
%
% eta : Proportion of strong individuals in the population
%       The small offsets (1e-6) avoid singularities at eta = 0 or 1
%% ============================================================

eta = linspace(1e-6, 1 - 1e-6, 10000);

%% ============================================================
% Figure and axis configuration
%% ============================================================

figure('Position', [100, 100, 600, 600]); hold on;
xlabel(['Proportion of the strong, ', '$\eta$'], ...
    'FontSize', 23, 'Interpreter', 'latex');
ylabel(['Relative strength ratio,',' $\lambda$'], ...
    'FontSize', 23, 'Interpreter', 'latex');
set(gca, 'FontSize', 23);
ax = gca;
ax.LineWidth = 1;        
box on;

xlim([0 1]); 
ylim([0 1]);
xticks(0:0.2:1); 
yticks(0:0.2:1);

%% ============================================================
% Color definitions for different parameter regions
%% ============================================================

colors = [
    0.9 0.4 0.4;   % Color for Region 1 (reddish)
    0.4 0.4 0.9;   % Color for Region 2 (bluish)
    0.6 0.9 0.6    % Color for Region 3 (greenish)
];

%% ============================================================
% Region 1: analytically defined boundaries
%
% eta1_low, eta1_mid, eta1_high : critical eta values delimiting subregions
% A(eta), B(eta)                : analytical expressions for the upper
%                                 and lower boundaries in lambda
%% ============================================================

eta1_low  = 0;
eta1_mid  = 20/109;
eta1_high = (1/43) * (-1 + 6 * sqrt(6));

A = @(x) (87 .* x) ./ (20 + 101 .* x);
B = @(x) 4 * sqrt(5) .* ...
    sqrt(-((-5 + 2 .* x + 43 .* x.^2) ./ (20 + 101 .* x).^2));

% Region 1a: lower part of Region 1
fill_region(eta, @(x) x > eta1_low & x < eta1_mid, ...
    @(x) zeros(size(x)), @(x) A(x) + B(x), ...
    colors(1,:), 'Region 1a');

% Region 1b: intermediate subregion with two analytical boundaries
fill_region(eta, @(x) x >= eta1_mid & x < eta1_high, ...
    @(x) A(x) - B(x), @(x) A(x) + B(x), ...
    colors(1,:), 'Region 1b');

%% ============================================================
% Region 2: analytically defined boundaries
%
% eta2_low, eta2_mid : critical eta values
% f2(eta), g2(eta)   : analytical boundary functions
%% ============================================================

eta2_low = (2/71) * (38 - 15 * sqrt(2));
eta2_mid = 5/9;

f2 = @(x) (23 .* (-1 + x)) ./ (-57 + 37 .* x);
g2 = @(x) 4 .* sqrt( ...
    -((56 - 152 .* x + 71 .* x.^2) ./ (-57 + 37 .* x).^2));

% Region 2a: bounded from below and above by analytical curves
fill_region(eta, @(x) x > eta2_low & x <= eta2_mid, ...
    @(x) f2(x) - g2(x), @(x) f2(x) + g2(x), ...
    colors(2,:), 'Region 2a');

% Region 2b: upper extension of Region 2
fill_region(eta, @(x) x > eta2_mid & x < 1, ...
    @(x) zeros(size(x)), @(x) f2(x) + g2(x), ...
    colors(2,:), 'Region 2b');

%% ============================================================
% Region 3: residual parameter region
%
% This region covers the entire unit square and is plotted last
% to ensure that it fills any remaining uncovered area
%% ============================================================

fill_region(eta, @(x) true(size(x)), ...
    @(x) zeros(size(x)), @(x) ones(size(x)), ...
    colors(3,:), 'Region 3');

%% ============================================================
% Final figure appearance
%% ============================================================

set(gcf, 'Color', 'w');
hold off;

%% ============================================================
% Auxiliary function for filling parameter regions
%
% x         : horizontal coordinate (eta)
% mask_fun : logical function defining where the region exists
% lower_fun: function defining the lower boundary in lambda
% upper_fun: function defining the upper boundary in lambda
% color    : RGB color of the region
% label    : label used for legend/display purposes
%% ============================================================

function fill_region(x, mask_fun, lower_fun, upper_fun, color, label)

    % Apply mask to select the relevant eta values
    mask = mask_fun(x);
    x_masked = x(mask);
    if isempty(x_masked)
        return;
    end

    % Evaluate lower and upper boundaries
    lower_val = lower_fun(x_masked);
    upper_val = upper_fun(x_masked);

    % Keep only values lying in the admissible [0,1] interval
    valid = (upper_val > lower_val) & (lower_val >= 0) & (upper_val <= 1);

    % Fill the admissible region
    if any(valid)
        fill([x_masked(valid), fliplr(x_masked(valid))], ...
             [lower_val(valid), fliplr(upper_val(valid))], ...
             color, 'FaceAlpha', 0.4, ...
             'EdgeColor', 'none', ...
             'DisplayName', label);
    end
end
