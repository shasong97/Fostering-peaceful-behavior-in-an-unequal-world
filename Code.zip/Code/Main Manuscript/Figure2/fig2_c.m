clc; clear; close all;

%% ============================================================
% Model parameters
%
% b      : Resource value
% c      : Cost suffered by the loser due to combat injuries
%          (assumed to satisfy c > b > 0)
% gamma  : Interaction intensity between individuals of different strength
%          (interaction intensity equals 1 for pairs of the same strength
%           and equals gamma for pairs of different strength)
%% ============================================================

c = 1;
b = 1/2;
gamma = 0.8;

%% ============================================================
% Relative strength ratios to be plotted
%
% lambda : Relative strength ratio (weak / strong)
%% ============================================================

lambda_values = [0.2, 0.4, 0.6, 0.8];

% Line colors corresponding to different lambda values
colors = lines(length(lambda_values));

%% ============================================================
% Parameter domain for the proportion of strong individuals
%
% eta : Proportion of strong individuals in the population
%% ============================================================

eta_values = linspace(0.01, 0.99, 100);

%% ============================================================
% Figure setup
%% ============================================================

figure('Position', [100, 100, 600, 600])
hold on;

%% ============================================================
% Loop over different relative strength ratios
%% ============================================================

for k = 1:length(lambda_values)

    lambda = lambda_values(k);   % Current relative strength ratio

    % Storage for the total fraction of Dove strategy
    P_C = zeros(size(eta_values));

    % Initial condition:
    % state(1) = x : fraction of Dove among strong individuals
    % state(2) = y : fraction of Dove among weak individuals
    initial_conditions = [0.5; 0.5];

    % Long time horizon to ensure convergence to steady state
    tspan = [0 1000000];

    % ----------------------------------------------------------
    % Sweep over eta
    % ----------------------------------------------------------

    for i = 1:length(eta_values)

        eta = eta_values(i);   % Current proportion of strong individuals

        % Solve the replicator dynamics
        [~, sol] = ode45(@(t, state) ...
            dynamics(t, state, c, b, lambda, eta, gamma), ...
            tspan, initial_conditions);

        % Steady-state values of Dove fractions
        x_final = sol(end, 1);   % Strong individuals
        y_final = sol(end, 2);   % Weak individuals

        % Weighted total fraction of Dove in the whole population
        P_C(i) = eta * x_final + (1 - eta) * y_final;
    end

    % Plot the total Dove fraction as a function of eta
    plot(eta_values, P_C, ...
        'LineWidth', 4, ...
        'Color', colors(k,:), ...
        'DisplayName', ['$\lambda = $' num2str(lambda)]);
end

%% ============================================================
% Reference line: F_Dove = 0.5
%% ============================================================

plot(eta_values, 0.5 * ones(size(eta_values)), '--k', ...
    'LineWidth', 4, ...
    'DisplayName', '$F_{\mathrm{Dove}}=0.5$');

%% ============================================================
% Axis labels and formatting
%% ============================================================

xlabel(['Proportion of the strong, ', '$\eta$'], ...
    'FontSize', 23, 'Interpreter', 'latex');
ylabel('$F_{\mathrm{Dove}}$', ...
    'FontSize', 23, ...
    'FontAngle', 'italic', ...
    'Interpreter', 'latex');

set(gca, 'FontSize', 23);
ax = gca;
ax.LineWidth = 2;

box on;
legend('show', 'Interpreter', 'latex', 'Location', 'best');

xlim([0 1]);
ylim([0.4 0.8]);
xticks(0:0.2:1);
yticks(0:0.2:1);

hold off;

%% ============================================================
% Replicator dynamics for a heterogeneous Hawk–Dove population
%% ============================================================

function dstate_dt = dynamics(~, state, c, b, lambda, eta, gamma)

    % ----------------------------------------------------------
    % Time-scale parameter controlling the speed of evolution
    % ----------------------------------------------------------
    omega = 0.01;

    % ----------------------------------------------------------
    % State variables
    %
    % x : Fraction of Dove strategy among strong individuals
    % y : Fraction of Dove strategy among weak individuals
    % ----------------------------------------------------------
    x = state(1);
    y = state(2);

    % ----------------------------------------------------------
    % Expected payoffs of the Dove strategy
    %
    % PD1 : Dove payoff for strong individuals
    % PD2 : Dove payoff for weak individuals
    % ----------------------------------------------------------
    PD1 = (b/2) * eta * x ...
        + gamma * (b / (1 + lambda)) * (1 - eta) * y;

    PD2 = (b/2) * (1 - eta) * y ...
        + gamma * ((lambda * b) / (1 + lambda)) * eta * x;

    % ----------------------------------------------------------
    % Expected payoffs of the Hawk strategy
    %
    % PH1 : Hawk payoff for strong individuals
    % PH2 : Hawk payoff for weak individuals
    % ----------------------------------------------------------
    PH1 = b * eta * x ...
        + ((b - c) / 2) * eta * (1 - x) ...
        + gamma * ( ...
            b * (1 - eta) * y ...
            + ( (b / (1 + lambda)) - (lambda * c) / (1 + lambda) ) ...
              * (1 - eta) * (1 - y) );

    PH2 = b * (1 - eta) * y ...
        + ((b - c) / 2) * (1 - eta) * (1 - y) ...
        + gamma * ( ...
            b * eta * x ...
            + ( (lambda * b) / (1 + lambda) - c / (1 + lambda) ) ...
              * eta * (1 - x) );

    % ----------------------------------------------------------
    % Average payoff in each subpopulation
    % ----------------------------------------------------------
    aver1 = x * PD1 + (1 - x) * PH1;   % Strong individuals
    aver2 = y * PD2 + (1 - y) * PH2;   % Weak individuals

    % ----------------------------------------------------------
    % Replicator dynamics (scaled by omega/2)
    % ----------------------------------------------------------
    FX = omega / 2 * x * (PD1 - aver1);
    FY = omega / 2 * y * (PD2 - aver2);

    % Time derivatives
    dstate_dt = [FX; FY];
end
