clc; clear; close all;

%% ============================================================
% Model parameters
%
% b      : Resource value
% c      : Cost suffered by the loser in a conflict (combat injury),
%          satisfying c > b > 0
% gamma  : Interaction intensity between individuals of different strength
%          (interaction intensity is normalized to 1 for same-strength pairs,
%           and equals gamma for different-strength pairs)
%% ============================================================

c = 1;
b = 0.5;
gamma = 0.8;

%% ============================================================
% Parameter space for heterogeneity
%
% eta    : Proportion of strong individuals in the population
% lambda : Relative strength ratio (weak / strong)
%% ============================================================

eta_values    = linspace(0.01, 0.99, 100);   % Proportion of strong individuals
lambda_values = linspace(0, 1, 102);         % Relative strength ratio

% Total fraction of Dove strategy in the whole population
P_C = zeros(length(eta_values), length(lambda_values));

%% ============================================================
% Numerical settings
%
% state(1) = x : Fraction of Dove among strong individuals
% state(2) = y : Fraction of Dove among weak individuals
%% ============================================================

initial_conditions = [0.5; 0.5];   % Initial fractions of Dove in both groups
tspan = [0 2000];                  % Time horizon (long enough to reach steady state)

%% ============================================================
% Parameter sweep over (eta, lambda)
%% ============================================================

for i = 1:length(eta_values)
    for j = 1:length(lambda_values)

        eta    = eta_values(i);        % Current proportion of strong individuals
        lambda = lambda_values(j);     % Current relative strength ratio

        % Solve the replicator dynamics
        [~, sol] = ode45(@(t, state) ...
            dynamics(t, state, c, b, lambda, eta, gamma), ...
            tspan, initial_conditions);

        % Steady-state fractions of Dove
        x_final = sol(end, 1);   % Strong individuals
        y_final = sol(end, 2);   % Weak individuals

        % Weighted total fraction of Dove in the whole population
        P_C(i, j) = eta * x_final + (1 - eta) * y_final;
    end
end

%% ============================================================
% Redefine grids for plotting
%% ============================================================

eta_values    = linspace(0, 1, 102);
lambda_values = linspace(0, 1, 102);

%% ============================================================
% Visualization: heatmap of Dove frequency
%% ============================================================

figure('Position', [100, 100, 660, 600])
imagesc(eta_values, lambda_values, P_C');
set(gca, 'YDir', 'normal');

% Colorbar settings
c = colorbar;
c.Label.String = '$F_{\mathrm{Dove}}$';
c.Label.FontSize = 25;
c.Label.FontWeight = 'bold';
c.Label.Interpreter = 'latex';

% Axis labels
xlabel(['Proportion of the strong, ', '$\eta$'], ...
    'FontSize', 23, 'Interpreter', 'latex');
ylabel(['Relative strength ratio,', ' $\lambda$'], ...
    'FontSize', 23, 'Interpreter', 'latex');

% Axis appearance
set(gca, 'FontSize', 23);
ax = gca;
ax.LineWidth = 1;
box on;
colormap(sky);
xlim([0 1]);
ylim([0 1]);
xticks(0:0.2:1);
yticks(0:0.2:1);

%% ============================================================
% Replicator dynamics for a heterogeneous Hawk–Dove population
%% ============================================================

function dstate_dt = dynamics(~, state, c, b, lambda, eta, gamma)

    % ----------------------------------------------------------
    % State variables
    %
    % x : Fraction of Dove strategy among strong individuals
    % y : Fraction of Dove strategy among weak individuals
    % ----------------------------------------------------------

    x = state(1);
    y = state(2);

    % ----------------------------------------------------------
    % Expected payoffs of Dove strategy
    %
    % PD1 : Dove payoff for strong individuals
    % PD2 : Dove payoff for weak individuals
    % ----------------------------------------------------------

    PD1 = (b/2) * eta * x ...
        + gamma * (b / (1 + lambda)) * (1 - eta) * y;

    PD2 = (b/2) * (1 - eta) * y ...
        + gamma * ((lambda * b) / (1 + lambda)) * eta * x;

    % ----------------------------------------------------------
    % Expected payoffs of Hawk strategy
    %
    % PH1 : Hawk payoff for strong individuals
    % PH2 : Hawk payoff for weak individuals
    % ----------------------------------------------------------

    PH1 = b * eta * x ...
        + ((b - c) / 2) * eta * (1 - x) ...
        + gamma * ( ...
            b * (1 - eta) * y ...
            + ( (b / (1 + lambda)) - (lambda * c) / (1 + lambda) ) ...
              * (1 - eta) * (1 - y) );

    PH2 = b * (1 - eta) * y ...
        + ((b - c) / 2) * (1 - eta) * (1 - y) ...
        + gamma * ( ...
            b * eta * x ...
            + ( (lambda * b) / (1 + lambda) - c / (1 + lambda) ) ...
              * eta * (1 - x) );

    % ----------------------------------------------------------
    % Average payoff in each subpopulation
    % ----------------------------------------------------------

    aver1 = x * PD1 + (1 - x) * PH1;   % Strong individuals
    aver2 = y * PD2 + (1 - y) * PH2;   % Weak individuals

    % ----------------------------------------------------------
    % Replicator dynamics
    % ----------------------------------------------------------

    FX = x * (PD1 - aver1);   % Dynamics of Dove among strong individuals
    FY = y * (PD2 - aver2);   % Dynamics of Dove among weak individuals

    dstate_dt = [FX; FY];
end
