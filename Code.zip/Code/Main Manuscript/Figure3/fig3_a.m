clc; clear; close all;

%% ============================================================
% Parameter domain
%
% eta : Proportion of strong individuals in the population.
%       Small offsets (1e-6) are used to avoid singularities at
%       eta = 0 and eta = 1.
%
% lambda_split : Threshold value of the relative strength ratio
%                used to split each region into lower- and
%                higher-lambda subregions.
%% ============================================================

eta = linspace(1e-6, 1 - 1e-6, 10000);
lambda_split = 3/5;

%% ============================================================
% Figure and axis configuration
%% ============================================================

figure('Position', [100, 100, 600, 600]); hold on;
xlabel(['Proportion of the strong, ', '$\eta$'], ...
    'FontSize', 23, 'Interpreter', 'latex');
ylabel(['Relative strength ratio, ', '$\lambda$'], ...
    'FontSize', 23, 'Interpreter', 'latex');
set(gca, 'FontSize', 23, 'LineWidth', 1);
xlim([0 1]); 
ylim([0 1]);
xticks(0:0.2:1); 
yticks(0:0.2:1);
box on; 
grid off;

%% ============================================================
% Color definitions
%
% Each region is split into two parts:
%   - color_low  : lambda <= lambda_split
%   - color_high : lambda >  lambda_split
%% ============================================================

colors = [
    0.9  0.4  0.4;    % Color 1
    0.4  0.4  0.9;    % Color 2
    0.6  0.9  0.6;    % Color 3
    0.15 0.45 0.60;   % Color 4
    0.80 0.55 0.25;   % Color 5
    0.60 0.75 0.85;   % Color 6
];

%% ============================================================
% Region 1: analytically defined boundaries
%
% eta1_low, eta1_mid, eta1_high : critical eta values
% A(eta), B(eta)                : boundary functions in lambda
%% ============================================================

eta1_low  = 0;
eta1_mid  = 20/109;
eta1_high = (1/43) * (-1 + 6 * sqrt(6));

A = @(x) (87 .* x) ./ (20 + 101 .* x);
B = @(x) 4 * sqrt(5) .* ...
    sqrt(-((-5 + 2 .* x + 43 .* x.^2) ./ (20 + 101 .* x).^2));

% Region 1a: lower-eta part of Region 1
fill_split_region(eta, @(x) x > eta1_low & x < eta1_mid, ...
    @(x) zeros(size(x)), @(x) A(x) + B(x), ...
    colors(4,:), colors(1,:), lambda_split, 'Region 1a');

% Region 1b: intermediate eta range with two analytical boundaries
fill_split_region(eta, @(x) x >= eta1_mid & x < eta1_high, ...
    @(x) A(x) - B(x), @(x) A(x) + B(x), ...
    colors(4,:), colors(1,:), lambda_split, 'Region 1b');

%% ============================================================
% Region 2: analytically defined boundaries
%
% eta2_low, eta2_mid : critical eta values
% f2(eta), g2(eta)   : boundary functions in lambda
%% ============================================================

eta2_low = (2/71) * (38 - 15 * sqrt(2));
eta2_mid = 5/9;

f2 = @(x) (23 .* (-1 + x)) ./ (-57 + 37 .* x);
g2 = @(x) 4 .* sqrt( ...
    -((56 - 152 .* x + 71 .* x.^2) ./ (-57 + 37 .* x).^2));

% Region 2a: bounded from below and above by analytical curves
fill_split_region(eta, @(x) x > eta2_low & x <= eta2_mid, ...
    @(x) f2(x) - g2(x), @(x) f2(x) + g2(x), ...
    colors(5,:), colors(2,:), lambda_split, 'Region 2a');

% Region 2b: upper extension of Region 2
fill_split_region(eta, @(x) x > eta2_mid & x < 1, ...
    @(x) zeros(size(x)), @(x) f2(x) + g2(x), ...
    colors(5,:), colors(2,:), lambda_split, 'Region 2b');

%% ============================================================
% Region 3: residual region
%
% This region spans the entire unit square and is also split
% by lambda_split into lower and upper subregions.
%% ============================================================

fill_split_region(eta, @(x) true(size(x)), ...
    @(x) zeros(size(x)), @(x) ones(size(x)), ...
    colors(6,:), colors(3,:), lambda_split, 'Region 3');

%% ============================================================
% Auxiliary function for filling regions split by lambda_split
%
% x            : horizontal coordinate (eta)
% mask_fun     : logical function selecting the eta range
% lower_fun    : function defining the lower lambda boundary
% upper_fun    : function defining the upper lambda boundary
% color_low    : fill color for lambda <= lambda_split
% color_high   : fill color for lambda >  lambda_split
% lambda_split : splitting value of lambda
% label        : region label (used for display names)
%% ============================================================

function fill_split_region(x, mask_fun, lower_fun, upper_fun, ...
                           color_low, color_high, lambda_split, label)

    % Apply mask to select relevant eta values
    mask = mask_fun(x);
    x_masked = x(mask);
    if isempty(x_masked), return; end

    % Evaluate boundary functions
    lower_val = lower_fun(x_masked);
    upper_val = upper_fun(x_masked);

    % Keep only valid intervals
    valid = (upper_val > lower_val);
    if ~any(valid), return; end

    % Lower-lambda part (lambda <= lambda_split)
    fill([x_masked(valid), fliplr(x_masked(valid))], ...
         [lower_val(valid), fliplr(min(upper_val(valid), lambda_split))], ...
         color_low, 'FaceAlpha', 0.5, ...
         'EdgeColor', 'none', ...
         'DisplayName', [label, '_low']);

    % Upper-lambda part (lambda > lambda_split)
    upper_mask = upper_val > lambda_split;
    if any(upper_mask)
        fill([x_masked(upper_mask), fliplr(x_masked(upper_mask))], ...
             [max(lower_val(upper_mask), lambda_split), ...
              fliplr(min(upper_val(upper_mask), 1))], ...
             color_high, 'FaceAlpha', 0.45, ...
             'EdgeColor', 'none', ...
             'DisplayName', [label, '_high']);
    end
end
