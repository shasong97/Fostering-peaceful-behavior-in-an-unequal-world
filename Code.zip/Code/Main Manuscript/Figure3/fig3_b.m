clc; clear; close all;

%% ============================================================
% Grid resolution and mesh creation
%
% N_eta, N_lambda : number of points in eta and lambda directions
% eta_vals, lambda_vals : linearly spaced vectors for eta and lambda
% [ETA, LAMBDA] : 2D meshgrid for logical indexing and plotting
%% ============================================================

N_eta = 2000; 
N_lambda = 2000; 
eta_vals = linspace(0,1,N_eta);
lambda_vals = linspace(0,1,N_lambda);
[ETA, LAMBDA] = meshgrid(eta_vals, lambda_vals);

%% ============================================================
% Region 4 definition: bounded by analytical curves and upper limit 1/3
%
% eta2_low : lower bound of eta for Region 4
% f2(eta), g2(eta) : analytical functions defining lambda boundaries
%% ============================================================

eta2_low = (2/71)*(38 - 15*sqrt(2));
f2 = @(eta) (23*(eta-1))./(-57 + 37*eta);
g2 = @(eta) 4*sqrt(-((56 - 152*eta + 71*eta.^2)./(-57 + 37*eta).^2));

Region4 = (ETA > eta2_low) & (ETA <= 1) & ...
          (LAMBDA > f2(ETA) - g2(ETA)) & ...
          (LAMBDA < min(f2(ETA)+g2(ETA), 1/3));

%% ============================================================
% Region 5 definition: lower-triangle region in the lambda-eta plane
%
% eta5_lower : eta boundary as a function of lambda
%% ============================================================

eta5_lower = (1 + LAMBDA)./(3 - 5*LAMBDA);
Region5 = (LAMBDA >= 0) & (LAMBDA <= 1/3) & (ETA >= eta5_lower);

%% ============================================================
% Region 7 definition: part of Region5 excluding Region4
%% ============================================================

Region7 = Region5 & (~Region4);

%% ============================================================
% Figure setup
%% ============================================================

figure('Position',[100,100,600,600]); hold on;

eta = linspace(1e-6, 1-1e-6, 20000); % High-resolution eta for fill_region

% Define colors for different regions
colors = [
    0.9 0.4 0.4;    % Region 1
    0.4 0.4 0.9;    % Region 2
    0.6 0.9 0.6;    % Region 3
    0.75 0.05 0.15; % Region 4
    0.76 0.89 0.93; % Region 7
];

% Auxiliary function for upper lambda boundary in Region 4
lambda_upper_from_eta = @(eta) (3*eta - 1)./(5*eta + 1);

%% ============================================================
% Fill Region 4
% - Lower boundary: max(0, f2 - g2)
% - Upper boundary: min(f2 + g2, 1/3, lambda_upper_from_eta)
%% ============================================================

fill_region(eta, @(x)x > eta2_low & x <= 1, ...
    @(x) max(0, f2(x)-g2(x)), ...
    @(x) arrayfun(@(xx) min([f2(xx)+g2(xx), 1/3, lambda_upper_from_eta(xx)]), x), ...
    colors(4,:), 'Region 4');

%% ============================================================
% Fill Region 1: two subregions (1a, 1b)
%% ============================================================

eta1_low  = 0;
eta1_mid  = 20/109;
eta1_high = (1/43)*(-1 + 6*sqrt(6));
A = @(x) (87.*x)./(20 + 101.*x);
B = @(x) 4*sqrt(5).*sqrt(-((-5 + 2.*x + 43.*x.^2)./(20 + 101.*x).^2));

fill_region(eta, @(x)x > eta1_low & x < eta1_mid, @(x)zeros(size(x)), @(x)A(x)+B(x), colors(1,:), 'Region 1a');
fill_region(eta, @(x)x >= eta1_mid & x < eta1_high, @(x)A(x)-B(x), @(x)A(x)+B(x), colors(1,:), 'Region 1b');

%% ============================================================
% Fill Region 2: two subregions (2a, 2b)
%% ============================================================

eta2_mid = 5/9;
fill_region(eta, @(x)x > eta2_low & x <= eta2_mid, @(x)f2(x)-g2(x), @(x)f2(x)+g2(x), colors(2,:), 'Region 2a');
fill_region(eta, @(x)x > eta2_mid & x < 1, @(x)zeros(size(x)), @(x)f2(x)+g2(x), colors(2,:), 'Region 2b');

%% ============================================================
% Fill Region 3: full unit square
%% ============================================================

fill_region(eta, @(x)true(size(x)), @(x)zeros(size(x)), @(x)ones(size(x)), colors(3,:), 'Region 3');

%% ============================================================
% Overlay Region 7 using contourf for visual transparency
%% ============================================================

contourf(ETA, LAMBDA, Region7, [0.5 0.5], 'LineColor','none');
colormap([colors(5,:)]); 
alpha(0.4);

%% ============================================================
% Axis labels and formatting
%% ============================================================

xlabel('Proportion of the strong, $\eta$', 'Interpreter','latex','FontSize',23);
ylabel('Relative strength ratio, $\lambda$', 'Interpreter','latex','FontSize',23);
xticks(0:0.2:1);
xlim([0 1]); 
ylim([0 1]); 
set(gca,'FontSize',23); 
box on;
set(gcf,'Color','w'); 
hold off;

%% ============================================================
% Auxiliary function to fill a region between lower and upper bounds
%
% x        : horizontal coordinate (eta)
% mask_fun : logical function defining which x points to include
% lower_fun: function giving lower boundary of lambda
% upper_fun: function giving upper boundary of lambda
% color    : fill color for the region
% label    : string label for region (used in DisplayName)
%% ============================================================

function fill_region(x, mask_fun, lower_fun, upper_fun, color, label)
    % Apply mask to select relevant eta values
    mask = mask_fun(x);
    x_masked = x(mask);
    if isempty(x_masked), return; end
    
    % Evaluate boundaries
    lower_val = lower_fun(x_masked);
    upper_val = upper_fun(x_masked);
    
    % Keep only valid intervals within [0,1]
    valid = (upper_val > lower_val) & (lower_val >= 0) & (upper_val <= 1);
    if any(valid)
        % Fill the polygon corresponding to the region
        fill([x_masked(valid), fliplr(x_masked(valid))], ...
             [lower_val(valid), fliplr(upper_val(valid))], ...
             color, 'FaceAlpha',0.55, 'EdgeColor','none', 'DisplayName', label);
    end
end
