clc; clear; close all;

%% ============================================================
% Define the resolution of the grid and create mesh
%
% n        : number of points in eta and lambda directions
% eta      : linearly spaced vector of eta values (proportion of strong)
% lambda   : linearly spaced vector of lambda values (relative strength ratio)
% [ETA,LAMBDA] : meshgrid for logical indexing and contour plotting
%% ============================================================

n = 1000;
eta = linspace(0, 1, n);
lambda = linspace(0, 1, n);
[ETA, LAMBDA] = meshgrid(eta, lambda);

%% ============================================================
% Region 1 definition: high lambda, full eta range
%% ============================================================

Region1 = (ETA > 0 & ETA < 1) & (LAMBDA > 3/5 & LAMBDA <= 1);

%% ============================================================
% Region 2 definition: upper-triangle region for large eta
%
% lambda2_upper : upper boundary of lambda as a function of eta
%% ============================================================

lambda2_upper = (10 - 13*ETA) ./ (-10 + 5*ETA);
Region2 = (ETA > 5/6 & ETA < 1) & (LAMBDA > 1/7 & LAMBDA < lambda2_upper);

%% ============================================================
% Region 3 definition: two subregions 3a and 3b
%
% expr3a, expr3b : analytical expressions defining lambda boundaries for Region3a
% Region3a        : part of eta range with variable lambda boundaries
% Region3b        : constant lambda range for remaining eta
% Region3         : union of 3a and 3b
%% ============================================================

expr3a = (-82 + 87*ETA) ./ (-134 + 109*ETA);
expr3b = 4 * sqrt(5) .* sqrt(-(60 - 108*ETA + 43*ETA.^2) ./ (-134 + 109*ETA).^2);
Region3a = (ETA > 5/6 & ETA <= 86/101) & ...
           (LAMBDA > (expr3a - expr3b)) & (LAMBDA < 1/7);
Region3b = (ETA > 86/101 & ETA < 1) & (LAMBDA >= 0 & LAMBDA < 1/7);
Region3 = Region3a | Region3b;

%% ============================================================
% Region 4 definition: three subregions 4a, 4b, 4c
%
% expr4b, expr4c : analytical expressions for lambda boundaries in subregions
% lambda4c_lower : lower lambda boundary for Region4c
% Region4        : union of all subregions
%% ============================================================

expr4b = (5 + 23*ETA) ./ (15 * (1 + 3*ETA));
expr4c = (4/15) * sqrt(-(-25 - 50*ETA + 71*ETA.^2) ./ (1 + 3*ETA).^2);
Region4a = (ETA > 0 & ETA < 25/37) & (LAMBDA >= 0 & LAMBDA < 3/5);
Region4b = (ETA >= 25/37 & ETA <= 5/6) & ...
           (LAMBDA > (expr4b - expr4c)) & (LAMBDA < 3/5);
lambda4c_lower = (10 - 13*ETA) ./ (-10 + 5*ETA);
Region4c = (ETA > 5/6 & ETA < 1) & ...
           (LAMBDA > lambda4c_lower) & (LAMBDA < 3/5);
Region4 = Region4a | Region4b | Region4c;

%% ============================================================
% Region 5 definition: two subregions 5a and 5b
%
% Region5a : lower lambda portion in eta range 25/37 to 5/6
% Region5b : lower lambda portion in eta range 5/6 to 86/101
% Region5  : union of subregions
%% ============================================================

Region5a = (ETA > 25/37 & ETA <= 5/6) & ...
           (LAMBDA >= 0 & LAMBDA < (expr4b - expr4c));
Region5b = (ETA > 5/6 & ETA < 86/101) & ...
           (LAMBDA >= 0 & LAMBDA < (expr3a - expr3b));
Region5 = Region5a | Region5b;

%% ============================================================
% Define colors for the different regions
%% ============================================================

colors = [
    0.52, 0.70, 0.72; % Region 1
    0.72, 0.70, 0.52; % Region 2
    0.88, 0.78, 0.42; % Region 3
    0.6 0.9 0.6;      % Region 4
    0.80, 0.62, 0.75  % Region 5
];

%% ============================================================
% Set up figure
%% ============================================================

figure('Position', [100, 100, 600, 600]); hold on;
xlabel('Proportion of the strong, $\eta$', 'Interpreter', 'latex', 'FontSize', 22);
ylabel('Relative strength ratio, $\lambda$', 'Interpreter', 'latex', 'FontSize', 22);
set(gca, 'FontSize', 22, 'LineWidth', 1);
xlim([0 1]); ylim([0 1]);
xticks(0:0.2:1); yticks(0:0.2:1);
box on;

%% ============================================================
% Plot filled contours for each region in order of layering
%
% contourf arguments:
% ETA,LAMBDA    : meshgrid coordinates
% double(RegionX): convert logical array to double for contourf
% [0.5 1.5]    : contour levels
% 'FaceColor'  : color of the filled region
% 'EdgeColor'  : no border lines
% 'FaceAlpha'  : transparency
%% ============================================================

contourf(ETA, LAMBDA, double(Region5), [0.5 1.5], ...
    'FaceColor', colors(5,:), 'EdgeColor', 'none', 'FaceAlpha', 0.5);
contourf(ETA, LAMBDA, double(Region4), [0.5 1.5], ...
    'FaceColor', colors(4,:), 'EdgeColor', 'none', 'FaceAlpha', 0.5);
contourf(ETA, LAMBDA, double(Region3), [0.5 1.5], ...
    'FaceColor', colors(3,:), 'EdgeColor', 'none', 'FaceAlpha', 0.5);
contourf(ETA, LAMBDA, double(Region2), [0.5 1.5], ...
    'FaceColor', colors(2,:), 'EdgeColor', 'none', 'FaceAlpha', 0.6);
contourf(ETA, LAMBDA, double(Region1), [0.5 1.5], ...
    'FaceColor', colors(1,:), 'EdgeColor', 'none', 'FaceAlpha', 0.6);

%% ============================================================
% Set figure background color and finish
%% ============================================================

set(gcf, 'Color', 'w'); hold off;
