clc; clear; close all;

%% ============================================================
% Parameter definition
%
% z : control parameter determining regions
%% ============================================================

z = 1;

%% ============================================================
% Create meshgrid for eta (proportion of strong) and lambda (relative strength ratio)
%
% n        : resolution of grid
% eta      : linearly spaced vector from 0 to 1
% lambda   : linearly spaced vector from 0 to 1
% [ETA,LAMBDA] : meshgrid for logical indexing and plotting
%% ============================================================

n = 1000;
eta = linspace(0, 1, n);
lambda = linspace(0, 1, n);
[ETA, LAMBDA] = meshgrid(eta, lambda);

%% ============================================================
% Initialize Region1 as empty logical array
%% ============================================================

Region1 = false(size(ETA));

%% ============================================================
% Define Region1 for z in (3/4,5/6]
%
% lambda_low : lower lambda boundary
% eta_lower  : lower eta boundary as function of lambda
% eta_upper  : upper eta boundary as function of lambda
% mask1      : logical mask for points in Region1
%% ============================================================

if z > 3/4 && z <= 5/6
    lambda_low = -8 * sqrt(3) * sqrt((-3 + 4*z) / (-25 + 12*z)^2) + (-7 - 12*z)/(-25 + 12*z);
    eta_lower = (5 + 5.*LAMBDA - 6*z - 6*z.*LAMBDA) ./ (-3 + 5*LAMBDA);
    eta_upper = (8.*LAMBDA - 6*z - 6*z.*LAMBDA) ./ (-5 + 3*LAMBDA);
    mask1 = (LAMBDA > lambda_low) & (LAMBDA <= 1) & (ETA > eta_lower) & (ETA < eta_upper);
    Region1 = Region1 | mask1;
end

%% ============================================================
% Define Region1 for z in (5/6,1]
%
% threshold   : lambda threshold separating two conditions
% eta_thresh  : eta threshold as function of lambda
% cond1, cond2: logical masks for subregions
%% ============================================================

if z > 5/6 && z <= 1
    threshold = (4 - 3*z)/(3*z);
    eta_thresh = (5 + 5.*LAMBDA - 6*z - 6*z.*LAMBDA) ./ (-3 + 5*LAMBDA);

    cond1 = (LAMBDA >= 0) & (LAMBDA < threshold) & (ETA > 0) & (ETA < eta_thresh);
    cond2 = (LAMBDA >= threshold) & (LAMBDA <= 1) & (ETA > 0) & (ETA < 1);
    Region1 = Region1 | cond1 | cond2;
end

%% ============================================================
% Define Region2: upper-triangle region for large eta
%% ============================================================

Region2 = (ETA > 11/13 & ETA < 1) & (LAMBDA >= 0 & LAMBDA < (11 - 13*ETA)./(-11 + 5*ETA));

%% ============================================================
% Define Region3: two-part region with variable lambda boundaries
%
% cond3a : lower eta range
% cond3b : upper eta range
% Region3: union of cond3a and cond3b
%% ============================================================

cond3a = (ETA > 1/3 & ETA < 11/13) & (LAMBDA >= 0 & LAMBDA < (-1 + 3*ETA)./(1 + 5*ETA));
cond3b = (ETA >= 11/13 & ETA < 1) & ...
    ((11 - 13*ETA)./(-11 + 5*ETA) < LAMBDA & LAMBDA < (-1 + 3*ETA)./(1 + 5*ETA));
Region3 = cond3a | cond3b;

%% ============================================================
% Set up figure
%% ============================================================

figure('Position', [100, 100, 600, 600]); hold on;
xlabel('The proportion of the strong, $\eta$', 'FontSize', 23, 'Interpreter', 'latex');
ylabel('Relative strength ratio, $\lambda$', 'FontSize', 23, 'Interpreter', 'latex');
set(gca, 'FontSize', 23);
ax = gca;
ax.LineWidth = 1;       
box on;
xlim([0 1]); ylim([0 1]);
xticks(0:0.2:1); yticks(0:0.2:1);

%% ============================================================
% Define colors for the regions
%% ============================================================

colors = [
    0.72, 0.70, 0.52;  % Region2
    0.52, 0.70, 0.72;  % Region1
    0.6 0.9 0.6         % Region3
];

%% ============================================================
% Plot Region3 (lowest layer)
%% ============================================================

contourf(ETA, LAMBDA, double(Region3), [0.5 1.5], ...
    'FaceColor', colors(3,:), 'EdgeColor', 'none', 'FaceAlpha', 0.4);

%% ============================================================
% Plot Region2 (middle layer)
%% ============================================================

contourf(ETA, LAMBDA, double(Region2), [0.5 1.5], ...
    'FaceColor', colors(1,:), 'EdgeColor', 'none', 'FaceAlpha', 0.5);

%% ============================================================
% Plot Region1 (top layer)
%% ============================================================

contourf(ETA, LAMBDA, double(Region1), [0.5 1.5], ...
    'FaceColor', colors(2,:), 'EdgeColor', 'none', 'FaceAlpha', 0.6);

%% ============================================================
% Finalize figure
%% ============================================================

set(gcf, 'Color', 'w'); hold off;
