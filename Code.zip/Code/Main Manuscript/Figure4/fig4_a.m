clc; clear; close all;

%% ============================================================
% Define eta and lambda grids
%
% eta_vals   : linearly spaced values for proportion of the strong
% lambda_vals: linearly spaced values for relative strength ratio
% [Eta,Lambda]: meshgrid for surface plotting
% Z          : parameter used in Beta calculation
%% ============================================================

eta_vals = linspace(0.01, 0.99, 400);
lambda_vals = linspace(0, 1, 400);
[Eta, Lambda] = meshgrid(eta_vals, lambda_vals);
Z = 1;  

%% ============================================================
% Compute Beta thresholds
%
% Beta_1, Beta_2 : formulas for threshold surfaces
% cond2_right     : logical mask for region where Beta_2 applies
% beta_thresh     : final threshold surface combining Beta_1 and Beta_2
%% ============================================================

Beta_1 = (5 + 3 * Eta + 5 * Lambda - 5 * Eta .* Lambda) ./ (20 * Z + 20 * Lambda * Z);
Beta_2 = (5 * Eta + 8 * Lambda - 3 * Eta .* Lambda) ./ (20 * Z + 20 * Lambda * Z);

cond2_right = (Eta > 0.5) & (Eta < 1) & (Lambda > (5 - 2 * Eta) ./ (3 + 2 * Eta)) & (Lambda <= 1);
beta_thresh = Beta_1;
beta_thresh(cond2_right) = Beta_2(cond2_right);

%% ============================================================
% Plot 3D surface of beta_thresh
%
% surf       : create 3D surface
% shading interp : smooth color interpolation
% colormap   : set color scheme (here sky colormap)
% EdgeColor  : remove surface grid lines
% FaceAlpha  : set transparency
% AlphaDataMapping : keep FaceAlpha uniform
%% ============================================================

figure('Position', [20, 20, 600, 600]);
s = surf(Eta, Lambda, beta_thresh, beta_thresh);  
shading interp;               
colormap(sky);                 
s.EdgeColor = 'none';         
s.FaceAlpha = 0.8;            
s.AlphaDataMapping = 'none';  

hold on;

%% ============================================================
% Define cube vertices for 3D reference
%
% xCube, yCube, zCube : coordinates of the cube corners
% edges                : pairs of indices defining cube edges
%% ============================================================

xCube = [0 1 1 0 0 1 1 0];
yCube = [0 0 1 1 0 0 1 1];
zCube = [0.2 0.2 0.2 0.2 0.4 0.4 0.4 0.4];  

edges = [1 2; 2 3; 3 4; 4 1;  % bottom face
         6 7; 7 8;             % top face (partial)
         2 6; 3 7; 4 8];       % vertical edges

%% ============================================================
% Plot cube edges on top of surface
%% ============================================================

for k = 1:size(edges,1)
    plot3(xCube(edges(k,:)), yCube(edges(k,:)), zCube(edges(k,:)), 'k-', 'LineWidth', 1.5);
end

%% ============================================================
% Set axes properties
%
% Font size, axis limits, ticks, view angle, and grid
%% ============================================================

set(gca, 'FontSize', 23);
ax = gca;
ax.LineWidth = 1;

xlim([0 1]); ylim([0 1]); zlim([0.2 0.4]);
xticks(0:0.5:1); yticks(0:0.5:1); zticks(0.2:0.1:0.4);

view(45,30); 
grid off;     
