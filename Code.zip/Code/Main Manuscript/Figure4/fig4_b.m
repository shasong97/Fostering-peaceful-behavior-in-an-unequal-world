clc; clear; close all;

%% ============================================================
% Define parameters for the simulation
%
% c, b        : payoff parameters
% gamma       : interaction strength between types
% eta         : proportion of strong individuals
% tspan       : time span for ODE integration
% N           : number of grid points for initial conditions
% threshold   : final state threshold for counting basin of attraction
% lambda_values: different relative strength ratios to analyze
% alpha_list, beta_list: range of intervention intensities to sweep
%% ============================================================

c = 1;
b = 0.5;
gamma = 0.8;
eta = 0.5; 
tspan = [0.1, 1000];

N = 50; 
threshold = 0.99;
lambda_values = [0.2, 0.5, 0.8];
alpha_list = linspace(0, 1, 50); 
beta_list = linspace(0, 1, 50);

%% ============================================================
% Generate 3D grid of initial conditions avoiding boundaries (0,1)
%
% ndgrid generates x0, y0, z0 grids
% initial_conditions_set: all combinations of initial states
% total_ic: total number of initial conditions
%% ============================================================

epsilon = 1e-3;
[x0, y0, z0] = ndgrid(linspace(epsilon, 1-epsilon, N), ...
                      linspace(epsilon, 1-epsilon, N), ...
                      linspace(epsilon, 1-epsilon, N));
initial_conditions_set = [x0(:), y0(:), z0(:)];
total_ic = size(initial_conditions_set, 1);

%% ============================================================
% Initialize structures to store volume fractions for alpha and beta
%% ============================================================

results_alpha = struct();
results_beta = struct();

%% ============================================================
% Compute basin of attraction volume fractions for alpha interventions
%
% Loop over lambda values, then over alpha values
% Integrate ODE for each initial condition using dynamics_alpha
% Count the fraction of initial conditions reaching threshold
%% ============================================================

for i = 1:length(lambda_values)
    lambda = lambda_values(i);
    vol_frac = zeros(size(alpha_list));
    for k = 1:length(alpha_list)
        alpha = alpha_list(k);
        count = 0;
        for ic = 1:total_ic
            init = initial_conditions_set(ic, :)';
            [~, sol] = ode45(@(t, state) dynamics_alpha(t, state, c, b, alpha, lambda, eta, gamma), tspan, init);
            final_state = sol(end, :);
            if final_state(1) >= threshold && final_state(2) >= threshold
                count = count + 1;
            end
        end
        vol_frac(k) = count / total_ic;
    end
    results_alpha(i).lambda = lambda;
    results_alpha(i).volume_fraction = vol_frac;
end

%% ============================================================
% Compute basin of attraction volume fractions for beta interventions
%
% Similar loop structure as for alpha
%% ============================================================

for i = 1:length(lambda_values)
    lambda = lambda_values(i);
    vol_frac = zeros(size(beta_list));
    for k = 1:length(beta_list)
        beta = beta_list(k);
        count = 0;
        for ic = 1:total_ic
            init = initial_conditions_set(ic, :)';
            [~, sol] = ode45(@(t, state) dynamics_beta(t, state, c, b, beta, lambda, eta, gamma), tspan, init);
            final_state = sol(end, :);
            if final_state(1) >= threshold && final_state(2) >= threshold
                count = count + 1;
            end
        end
        vol_frac(k) = count / total_ic;
    end
    results_beta(i).lambda = lambda;
    results_beta(i).volume_fraction = vol_frac;
end

%% ============================================================
% Define dynamics function for alpha interventions
%
% state = [x; y; z] : state variables
% FD1, FH1, FD2, FH2 : fitnesses for each type with intervention
% FI, FM             : aggregate fitness for z = 0 or z = 1
% aver1, aver2, aver3: average fitnesses for normalization
% dstate_dt          : time derivative of state
%% ============================================================

function dstate_dt = dynamics_alpha(~, state, c, b, alpha, lambda, eta, gamma)
    x = max(0, min(1, state(1))); 
    y = max(0, min(1, state(2))); 
    z = max(0, min(1, state(3)));

    PD1 = (b/2)*eta*x + gamma*(b/(1+lambda))*(1 - eta)*y;
    PH1 = b*eta*x + ((b - c)/2)*eta*(1 - x) + gamma*(b*(1 - eta)*y + ((b/(1+lambda)) - ((lambda*c)/(1+lambda)))*(1 - eta)*(1 - y));
    PD2 = (b/2)*(1 - eta)*y + gamma*((lambda*b)/(1+lambda))*eta*x;
    PH2 = (b*(1 - eta)*y + ((b - c)/2)*(1 - eta)*(1 - y)) + gamma*(b*eta*x + (((lambda*b)/(1+lambda)) - (c/(1+lambda)))*eta*(1 - x));

    FD1 = PD1;
    FH1 = PH1*(1 - z) + (PH1 - alpha)*z;
    FD2 = PD2;
    FH2 = PH2*(1 - z) + (PH2 - alpha)*z;

    FI = eta^2 * (b - (1 - x)^2 * c) + (1 - eta)^2 * (b - (1 - y)^2 * c) + 2 * gamma * eta * (1 - eta) * (b - (1 - x) * (1 - y) * c);
    FM = eta^2 * (b - (1 - x)^2 * c - 2 * alpha * (1 - x)) + ...
         (1 - eta)^2 * (b - (1 - y)^2 * c - 2 * alpha * (1 - y)) + ...
         2 * gamma * eta * (1 - eta) * (b - (1 - x) * (1 - y) * c - alpha * (2 - x - y));

    aver1 = x*FD1 + (1 - x)*FH1;
    aver2 = y*FD2 + (1 - y)*FH2;
    aver3 = (1 - z)*FI + z*FM;

    dstate_dt = [x*(FD1 - aver1); y*(FD2 - aver2); z*(FM - aver3)];
end

%% ============================================================
% Define dynamics function for beta interventions
%
% Similar structure as dynamics_alpha but with beta affecting FM differently
%% ============================================================

function dstate_dt = dynamics_beta(~, state, c, b, beta, lambda, eta, gamma)
    x = max(0, min(1, state(1))); 
    y = max(0, min(1, state(2))); 
    z = max(0, min(1, state(3)));

    PD1 = (b/2)*eta*x + gamma*(b/(1+lambda))*(1 - eta)*y;
    PH1 = b*eta*x + ((b - c)/2)*eta*(1 - x) + gamma*(b*(1 - eta)*y + ((b/(1+lambda)) - ((lambda*c)/(1+lambda)))*(1 - eta)*(1 - y));
    PD2 = (b/2)*(1 - eta)*y + gamma*((lambda*b)/(1+lambda))*eta*x;
    PH2 = (b*(1 - eta)*y + ((b - c)/2)*(1 - eta)*(1 - y)) + gamma*(b*eta*x + (((lambda*b)/(1+lambda)) - (c/(1+lambda)))*eta*(1 - x));

    FD1 = PD1;
    FH1 = PH1*(1 - z) + (PH1 - beta)*z;
    FD2 = PD2;
    FH2 = PH2*(1 - z) + (PH2 - beta)*z;

    FI = c * (eta^2 * (1 - x)^2 + (1 - eta)^2 * (1 - y)^2 + 2 * gamma * eta * (1 - eta) * (1 - x) * (1 - y));
    FM = eta^2 * (1 - x) * ((1 - x) * c + 2 * beta) + ...
         (1 - eta)^2 * (1 - y) * ((1 - y) * c + 2 * beta) + ...
         2 * gamma * eta * (1 - eta) * ((1 - x) * (1 - y) * c + beta * (2 - x - y));

    aver1 = x*FD1 + (1 - x)*FH1;
    aver2 = y*FD2 + (1 - y)*FH2;
    aver3 = (1 - z)*FI + z*FM;

    dstate_dt = [x*(FD1 - aver1); y*(FD2 - aver2); z*(FM - aver3)];
end

%% ============================================================
% Plot the volume fractions for both alpha and beta interventions
%
% Use solid lines for alpha, dashed lines for beta
% Color corresponds to lambda value
%% ============================================================

lambda_values = [0.2, 0.5, 0.8];
colors = lines(length(lambda_values));
figure('Position', [100, 100, 675, 600]); hold on;
legend_entries = {};

for i = 1:length(lambda_values)
    plot(alpha_list, results_alpha(i).volume_fraction, '-', 'LineWidth', 4, 'Color', colors(i, :));
    legend_entries{end+1} = sprintf('\\lambda = %.1f (\\alpha)', results_alpha(i).lambda);
end

for i = 1:length(lambda_values)
    plot(beta_list, results_beta(i).volume_fraction, '--', 'LineWidth', 4, 'Color', colors(i, :));
    legend_entries{end+1} = sprintf('\\lambda = %.1f (\\beta)', results_beta(i).lambda);
end

xlabel('The intensity of intervention, $\alpha$/$\beta$', 'Interpreter', 'latex', 'FontSize', 23);
ylabel({'Size of the basin of attraction', 'for the point $(1,1,\tilde{z})$'}, 'Interpreter', 'latex', 'FontSize', 23);
set(gca, 'FontSize', 23);
grid off;
xlim([0 1]); ylim([0 1]); box on;
xticks(0:0.2:1);
yticks(0:0.2:1);
ax = gca;
ax.LineWidth = 2;        
