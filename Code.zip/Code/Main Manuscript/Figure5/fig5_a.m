clc; clear; close all;

%% ============================================================
% Define a vector of eta values (proportion of strong individuals)
% to evaluate the piecewise function f(eta)
%% ============================================================

eta_values = linspace(0.01, 0.99, 1000);

%% ============================================================
% Define a piecewise function f(eta) with three intervals
%
% Interval 1: eta < 340/1223
% Interval 2: 340/1223 <= eta < 691/1031
% Interval 3: eta >= 691/1031
%
% Each interval has a different cubic-over-quadratic expression
%% ============================================================

f = @(eta) (eta < 340/1223) .* ((-7433.*eta.^3 + 9048.*eta.^2 - 1615.*eta)./(7433.*eta.^2 - 3230.*eta - 7225)) + ...
           (eta >= 340/1223 & eta < 691/1031) .* ((-13634.*eta.^3 + 19299.*eta.^2 - 5665.*eta)./(13634.*eta.^2 - 13634.*eta + 34085)) + ...
           (eta >= 691/1031) .* ((-4939.*eta.^3 + 7413.*eta.^2 - 2474.*eta)./(4939.*eta.^2 - 9028.*eta + 11314));

%% ============================================================
% Evaluate the function over the eta_values vector
%% ============================================================

f_values = f(eta_values);

%% ============================================================
% Create figure and plot f(eta) vs eta
%% ============================================================

figure('Position', [100, 100, 1750, 550]); hold on;
plot(eta_values, f_values, 'b-', 'LineWidth', 4);

%% ============================================================
% Mark break points where the piecewise function changes
%
% Plot red filled circles at break points
%% ============================================================

break_points = [340/1223, 691/1031];
for bp = break_points
    plot(bp, f(bp), 'ro', 'MarkerFaceColor', 'r', 'MarkerSize', 8);  
end

%% ============================================================
% Mark special points where f(eta) = 0 (optional zeros of interest)
%
% Plot green filled circles at special points
%% ============================================================

special_points = [0.2173, 0.4155];
for sp = special_points
    plot(sp, 0, 'go', 'MarkerFaceColor', 'g', 'MarkerSize', 8);
end

%% ============================================================
% Configure axes labels, font size, and plot appearance
%% ============================================================

xlabel('The proportion of the strong, $\eta$', 'FontSize', 23, 'Interpreter', 'latex');
ylabel('Derivative, $\dot\eta$', 'FontSize', 23, 'FontAngle', 'italic', 'Interpreter', 'latex');
yline(0, 'k--', 'LineWidth', 1.2);  % horizontal line at zero
xticks(0:0.2:1);                    % x-axis ticks
ax = gca;
ax.LineWidth = 2;       
set(gca, 'FontSize', 23);
box on;
