clc; clear; close all;

%% ============================================================
% Set model parameters
%% ============================================================
c = 1;                  % cost parameter
b = 0.5;                % benefit parameter
lambda = 0.7;           % fixed relative strength ratio

%% ============================================================
% Define target gamma values and corresponding plotting colors
%% ============================================================
gamma_targets = [0.4, 0.6, 0.8, 0.9];  
colors = [0.2, 0.3, 0.5, 0.8];  % line color codes

%% ============================================================
% Define a vector of eta values (proportion of strong individuals)
%% ============================================================
eta_values = linspace(0.01, 0.99, 100);

%% ============================================================
% Set initial conditions for state variables x and y
% tspan specifies the time interval for ODE integration
%% ============================================================
x0 = 0.5; y0 = 0.5;
initial_conditions = [x0; y0];
tspan = [0 10000];

%% ============================================================
% Create figure for plotting eta derivative dynamics
%% ============================================================
figure('Position', [100, 100, 540, 500]); hold on;

%% ============================================================
% Loop over each gamma target
% For each gamma, compute eta derivative over all eta values
%% ============================================================
for k = 1:length(gamma_targets)
    gamma = gamma_targets(k);
    deta_dt = zeros(size(eta_values));   % initialize derivative array
    
    for j = 1:length(eta_values)
        eta = eta_values(j);
        
        % Integrate the dynamics over time using ode45
        [~, sol] = ode45(@(t, state) dynamics(t, state, c, b, lambda, eta, gamma), tspan, initial_conditions);
        x = sol(end,1);   % final x value after integration
        y = sol(end,2);   % final y value after integration
        
        % Compute average payoffs for the two groups
        [aver1, aver2] = compute_averages(x, y, c, b, lambda, eta, gamma);
        
        % Compute eta derivative using the formula
        deta_dt(j) = eta * (1 - eta) * (aver1 - aver2)/(eta*aver1+(1-eta)*aver2);
    end
    
    % Plot eta derivative vs eta for current gamma
    plot(eta_values, deta_dt, [colors(k) '-'], 'LineWidth', 4, ...
         'DisplayName', ['\gamma = ', num2str(gamma)]);
    
end

%% ============================================================
% Add horizontal reference line at zero derivative
%% ============================================================
yline(0, 'k--', 'LineWidth', 4);

%% ============================================================
% Configure plot labels, fonts, axes, and legend
%% ============================================================
xlabel('The proportion of the strong, $\eta$', 'FontSize', 23, 'Interpreter', 'latex');
ylabel('Derivative, $\dot\eta$', 'FontSize', 23, 'FontAngle', 'italic', 'Interpreter', 'latex');
set(gca, 'FontSize', 23);
box on;
ax = gca;
ax.LineWidth = 2;       
legend('show');
xticks(0:0.2:1);

hold off;

%% ============================================================
% Subfunction: compute_averages
% Computes the average payoffs for strong (x) and weak (y) groups
%% ============================================================
function [aver1, aver2] = compute_averages(x, y, c, b, lambda, eta, gamma)
    
    % Payoffs for defecting and punishing in strong group
    PD1 = (b/2)*eta*x + gamma*(b/(1+lambda))*(1 - eta)*y;
    PH1 = b*eta*x + ((b - c)/2)*eta*(1 - x) + gamma*(b*(1 - eta)*y + ((b/(1+lambda)) - ((lambda*c)/(1+lambda)))*(1 - eta)*(1 - y));
    
    % Payoffs for defecting and punishing in weak group
    PD2 = (b/2)*(1 - eta)*y + gamma*((lambda*b)/(1+lambda))*eta*x;
    PH2 = (b*(1 - eta)*y + ((b - c)/2)*(1 - eta)*(1 - y)) + gamma*(b*eta*x + (((lambda*b)/(1+lambda)) - (c/(1+lambda)))*eta*(1 - x));

    % Compute average payoff for each group
    aver1 = x*PD1 + (1 - x)*PH1;
    aver2 = y*PD2 + (1 - y)*PH2;
end

%% ============================================================
% Subfunction: dynamics
% Defines the ODE system for state evolution of x and y
%% ============================================================
function dstate_dt = dynamics(~, state, c, b, lambda, eta, gamma)
    x = state(1);
    y = state(2);

    % Payoffs for defecting and punishing in strong group
    PD1 = (b/2)*eta*x + gamma*(b/(1+lambda))*(1 - eta)*y;
    PH1 = b*eta*x + ((b - c)/2)*eta*(1 - x) + gamma*(b*(1 - eta)*y + ((b/(1+lambda)) - ((lambda*c)/(1+lambda)))*(1 - eta)*(1 - y));
    
    % Payoffs for defecting and punishing in weak group
    PD2 = (b/2)*(1 - eta)*y + gamma*((lambda*b)/(1+lambda))*eta*x;
    PH2 = (b*(1 - eta)*y + ((b - c)/2)*(1 - eta)*(1 - y)) + gamma*(b*eta*x + (((lambda*b)/(1+lambda)) - (c/(1+lambda)))*eta*(1 - x));

    % Compute average payoffs for each group
    aver1 = x*PD1 + (1 - x)*PH1;
    aver2 = y*PD2 + (1 - y)*PH2;

    % Replicator dynamics equations for x and y
    FX = x * (PD1 - aver1);
    FY = y * (PD2 - aver2);

    dstate_dt = [FX; FY];
end
