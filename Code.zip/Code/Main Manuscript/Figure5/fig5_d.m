clc; clear; close all;

%% ============================================================
% Set model parameters
%% ============================================================
c = 1;                  % cost parameter
b = 0.5;                % benefit parameter

%% ============================================================
% Define a vector of eta values (proportion of strong individuals)
%% ============================================================
eta_values = linspace(0.01, 0.99, 200);

%% ============================================================
% Define vectors of lambda (relative strength) and gamma (interaction intensity)
%% ============================================================
lambda_values = linspace(0, 1, 50);
gamma_values = linspace(0, 1, 50);

%% ============================================================
% Initialize a matrix to store the number of roots of delta = aver1 - aver2
% Rows correspond to gamma, columns correspond to lambda
%% ============================================================
num_roots_map = zeros(length(gamma_values), length(lambda_values));

%% ============================================================
% Set initial conditions and ODE integration time span
%% ============================================================
x0 = 0.5; y0 = 0.5;
initial_conditions = [x0; y0];
tspan = [0 5000];

%% ============================================================
% Loop over each lambda value
%% ============================================================
for i = 1:length(lambda_values)
    lambda = lambda_values(i);
    
    %% Loop over each gamma value
    for j = 1:length(gamma_values)
        gamma = gamma_values(j);

        %% Compute delta values for all eta
        delta_vals = zeros(size(eta_values));
        for k = 1:length(eta_values)
            eta = eta_values(k);

            % Integrate the ODE system over time
            [~, sol] = ode45(@(t, state) dynamics(t, state, c, b, lambda, eta, gamma), tspan, initial_conditions);
            x = sol(end,1); % final x value
            y = sol(end,2); % final y value

            % Compute average payoffs for strong and weak groups
            [aver1, aver2] = compute_averages(x, y, c, b, lambda, eta, gamma);
            delta_vals(k) = aver1 - aver2; % difference of averages
        end

        %% Count the number of sign changes in delta_vals (number of roots)
        sign_change = delta_vals(1:end-1) .* delta_vals(2:end) < 0;
        num_roots = sum(sign_change);
        num_roots_map(j, i) = min(num_roots, 2);  % limit to max 2 roots for visualization
    end
end

%% ============================================================
% Subfunction: compute_averages
% Computes average payoffs for strong (x) and weak (y) groups
%% ============================================================
function [aver1, aver2] = compute_averages(x, y, c, b, lambda, eta, gamma)
    PD1 = (b/2)*eta*x + gamma*(b/(1+lambda))*(1 - eta)*y;
    PH1 = b*eta*x + ((b - c)/2)*eta*(1 - x) + gamma*(b*(1 - eta)*y + ((b/(1+lambda)) - ((lambda*c)/(1+lambda)))*(1 - eta)*(1 - y));
    PD2 = (b/2)*(1 - eta)*y + gamma*((lambda*b)/(1+lambda))*eta*x;
    PH2 = (b*(1 - eta)*y + ((b - c)/2)*(1 - eta)*(1 - y)) + gamma*(b*eta*x + (((lambda*b)/(1+lambda)) - (c/(1+lambda)))*eta*(1 - x));

    aver1 = x*PD1 + (1 - x)*PH1; % average payoff for strong group
    aver2 = y*PD2 + (1 - y)*PH2; % average payoff for weak group
end

%% ============================================================
% Subfunction: dynamics
% Defines the replicator dynamics ODE system for x and y
%% ============================================================
function dstate_dt = dynamics(~, state, c, b, lambda, eta, gamma)
    x = state(1);
    y = state(2);
    
    % Payoffs for defecting and punishing in strong group
    PD1 = (b/2)*eta*x + gamma*(b/(1+lambda))*(1 - eta)*y;
    PH1 = b*eta*x + ((b - c)/2)*eta*(1 - x) + gamma*(b*(1 - eta)*y + ((b/(1+lambda)) - ((lambda*c)/(1+lambda)))*(1 - eta)*(1 - y));
    
    % Payoffs for defecting and punishing in weak group
    PD2 = (b/2)*(1 - eta)*y + gamma*((lambda*b)/(1+lambda))*eta*x;
    PH2 = (b*(1 - eta)*y + ((b - c)/2)*(1 - eta)*(1 - y)) + gamma*(b*eta*x + (((lambda*b)/(1+lambda)) - (c/(1+lambda)))*eta*(1 - x));

    % Compute average payoffs for each group
    aver1 = x*PD1 + (1 - x)*PH1;
    aver2 = y*PD2 + (1 - y)*PH2;

    % Replicator dynamics equations
    FX = x * (PD1 - aver1);
    FY = y * (PD2 - aver2);
    dstate_dt = [FX; FY];
end

%% ============================================================
% Plot the number of roots map as an image
%% ============================================================
figure('Position', [100, 100, 500, 500]);
imagesc(lambda_values, gamma_values, num_roots_map);
set(gca, 'YDir', 'normal'); % make y-axis increase upwards

% Set colormap for visualizing 0,1,2 roots
colormap([0.8 0.8 0.8; 0.6 0.8 1; 0.1 0.4 0.8]);  

xlabel(['Relative strength ratio,',' $\lambda$'], 'FontSize', 23, 'Interpreter', 'latex');
ylabel(['Interaction intensity,', '$\gamma$'], 'FontSize', 23, 'Interpreter', 'latex');
set(gca, 'FontSize', 23);
ax = gca;
ax.LineWidth = 1;       
xlim([0 1]); ylim([0 1]);
xticks(0:0.2:1); yticks(0:0.2:1);
axis tight;
box on;
