clc; clear; close all;

%% ============================================================
% Set model parameters
%% ============================================================
c = 1;          % cost 
b = 0.5;        % benefit 
alpha = 0.25;   % intervention intensity
gamma = 0.8;    % interaction intensity

%% ============================================================
% Define parameter grids for η (proportion of strong) and λ (strength ratio)
%% ============================================================
eta_values = linspace(0.01, 0.99, 50);
lambda_values = linspace(0.01, 0.99, 50);

%% ============================================================
% Initialize matrices to store final states and average differences
%% ============================================================
x_final = zeros(length(lambda_values), length(eta_values));  % final x values
y_final = zeros(length(lambda_values), length(eta_values));  % final y values
z_final = zeros(length(lambda_values), length(eta_values));  % final z values
aver_diff = zeros(length(lambda_values), length(eta_values));  % difference of averages for analysis

%% ============================================================
% Set initial condition for all simulations
%% ============================================================
initial_conditions = [0.5; 0.5; 0.5];  % starting from intermediate mixed state

%% ============================================================
% Define time span for ODE integration
%% ============================================================
tspan = [0 700];

%% ============================================================
% Loop over all λ and η combinations to integrate dynamics
%% ============================================================
for i = 1:length(lambda_values)
    for j = 1:length(eta_values)
        eta = eta_values(j);       % current proportion of strong
        lambda = lambda_values(i); % current relative strength ratio
       
        % Integrate ODE system
        [~, sol] = ode45(@(t, state) dynamics(t, state, c, b, alpha, lambda, eta, gamma), tspan, initial_conditions);

        % Store final values
        x_final(i,j) = sol(end, 1);
        y_final(i,j) = sol(end, 2);
        z_final(i,j) = sol(end, 3);

        % Compute average payoffs and store their difference
        [aver1, aver2] = compute_averages(x_final(i,j), y_final(i,j), z_final(i,j), c, b, alpha, lambda, eta, gamma);
        aver_diff(i,j) = aver1 - aver2;
    end
end

%% ============================================================
% Threshold final states close to 1
%% ============================================================
x_final(x_final > 0.99) = 1;
y_final(y_final > 0.99) = 1;

%% ============================================================
% Plot heatmaps of final states
%% ============================================================
figure('Position', [100, 100, 1550, 380]);
colormap(sky);  % use 'sky' colormap

% Subplot for x_final
subplot(1,3,1);
imagesc(eta_values, lambda_values, x_final);
colorbar;
xlabel(['The proportion of the strong, ', '$\eta$'], 'FontSize', 20, 'Interpreter', 'latex');
ylabel(['Relative strength ratio,',' $\lambda$'], 'FontSize', 20, 'Interpreter', 'latex');
title('Stable values of $x$', 'FontSize', 20, 'Interpreter', 'latex');
axis xy;
set(gca, 'FontSize', 20);

% Subplot for y_final
subplot(1,3,2);
imagesc(eta_values, lambda_values, y_final);
colorbar;
xlabel(['The proportion of the strong, ', '$\eta$'], 'FontSize', 20, 'Interpreter', 'latex');
ylabel(['Relative strength ratio,',' $\lambda$'], 'FontSize', 20, 'Interpreter', 'latex');
title('Stable values of $y$', 'FontSize', 20, 'Interpreter', 'latex');
axis xy;
set(gca, 'FontSize', 20);

% Subplot for z_final
subplot(1,3,3);
imagesc(eta_values, lambda_values, z_final);
colorbar;
caxis([0 0.01]); % restrict color axis to visualize small z values
xlabel(['The proportion of the strong, ', '$\eta$'], 'FontSize', 20, 'Interpreter', 'latex');
ylabel(['Relative strength ratio,',' $\lambda$'], 'FontSize', 20, 'Interpreter', 'latex');
title('Stable values of $z$', 'FontSize', 20, 'Interpreter', 'latex');
axis xy;
set(gca, 'FontSize', 20);

%% ============================================================
% Function to compute average payoffs for x and y
%% ============================================================
function [aver1, aver2] = compute_averages(x, y, z, c, b, alpha, lambda, eta, gamma)

    % Payoffs for strong and weak cooperators/defectors
    PD1 = (b/2)*eta*x + gamma*(b/(1+lambda))*(1 - eta)*y;
    PH1 = b*eta*x + ((b - c)/2)*eta*(1 - x) + gamma*(b*(1 - eta)*y + ((b/(1+lambda)) - ((lambda*c)/(1+lambda)))*(1 - eta)*(1 - y));
    PD2 = (b/2)*(1 - eta)*y + gamma*((lambda*b)/(1+lambda))*eta*x;
    PH2 = (b*(1 - eta)*y + ((b - c)/2)*(1 - eta)*(1 - y)) + gamma*(b*eta*x + (((lambda*b)/(1+lambda)) - (c/(1+lambda)))*eta*(1 - x));

    % Modified payoffs including z-effect
    FD1 = PD1;
    FH1 = PH1*(1 - z) + (PH1 - alpha)*z;
    FD2 = PD2;
    FH2 = PH2*(1 - z) + (PH2 - alpha)*z;

    % Compute weighted average payoffs
    aver1 = x*FD1 + (1 - x)*FH1;
    aver2 = y*FD2 + (1 - y)*FH2;
end

%% ============================================================
% ODE system function
%% ============================================================
function dstate_dt = dynamics(~, state, c, b, alpha, lambda, eta, gamma)
    % Extract current state
    x = state(1);
    y = state(2);
    z = state(3);
    
    % Payoffs for strong and weak cooperators/defectors
    PD1 = (b/2)*eta*x + gamma*(b/(1+lambda))*(1 - eta)*y;
    PH1 = b*eta*x + ((b - c)/2)*eta*(1 - x) + gamma*(b*(1 - eta)*y + ((b/(1+lambda)) - ((lambda*c)/(1+lambda)))*(1 - eta)*(1 - y));
    PD2 = (b/2)*(1 - eta)*y + gamma*((lambda*b)/(1+lambda))*eta*x;
    PH2 = (b*(1 - eta)*y + ((b - c)/2)*(1 - eta)*(1 - y)) + gamma*(b*eta*x + (((lambda*b)/(1+lambda)) - (c/(1+lambda)))*eta*(1 - x));

    % Modified payoffs including z effect
    FD1 = PD1;
    FH1 = PH1*(1 - z) + (PH1 - alpha)*z;
    FD2 = PD2;
    FH2 = PH2*(1 - z) + (PH2 - alpha)*z;

    % Global fitness terms for population
    FI = eta^2 * (b - (1 - x)^2 * c) + (1 - eta)^2 * (b - (1 - y)^2 * c) + ...
    2 * gamma * eta * (1 - eta) * (b - (1 - x) * (1 - y) * c);
    
    FM = eta^2 * (b - (1 - x)^2 * c - 2 * alpha * (1 - x)) + ...
    (1 - eta)^2 * (b - (1 - y)^2 * c - 2 * alpha * (1 - y)) + ...
    2 * gamma * eta * (1 - eta) * (b - (1 - x) * (1 - y) * c - alpha * (2 - x - y));

    % Compute average payoffs
    aver1 = x*FD1 + (1 - x)*FH1;
    aver2 = y*FD2 + (1 - y)*FH2;
    aver3 = (1 - z)*FI + z*FM;

    % Replicator-like dynamics
    FX = x*(FD1 - aver1);
    FY = y*(FD2 - aver2);
    FZ = z*(FM - aver3);

    dstate_dt = [FX; FY; FZ];
end
