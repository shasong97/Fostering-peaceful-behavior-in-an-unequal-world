clc; clear; close all;

%% ============================================================
% Set model parameters
%% ============================================================
c = 1;          % cost
b = 0.5;        % benefit
alpha = 0.3;    % intervention intensity
lambda = 0.8;   % relative strength ratio
eta = 0.6;      % proportion of strong individuals
gamma = 0.8;    % interaction intensity

%% ============================================================
% Define initial conditions
%% ============================================================
initial_conditions_1 = [0.92; 0.92; 0.92]; % near all-cooperator state
initial_conditions_2 = [0.5; 0.5; 0.5];    % intermediate state

%% ============================================================
% Set time span for ODE integration
%% ============================================================
tspan = [0.1 1000000];

%% ============================================================
% Integrate dynamics for both sets of initial conditions
%% ============================================================
[t1, sol1] = ode45(@(t, state) dynamics(t, state, c, b, alpha, lambda, eta,gamma), tspan, initial_conditions_1);
[t2, sol2] = ode45(@(t, state) dynamics(t, state, c, b, alpha, lambda, eta,gamma), tspan, initial_conditions_2);

%% ============================================================
% Extract x, y, z trajectories
%% ============================================================
x1 = sol1(:, 1);
y1 = sol1(:, 2);
z1 = sol1(:, 3);

x2 = sol2(:, 1);
y2 = sol2(:, 2);
z2 = sol2(:, 3);

%% ============================================================
% Define colors for plotting
%% ============================================================
c1  = [210, 57, 24]/255;   % color for x
c2 = [229, 168, 75]/255;   % color for y
c3 = [73, 148, 196]/255;   % color for z

%% ============================================================
% Plot trajectories
%% ============================================================
figure('Position', [100, 100, 500, 500]);
hold on;

% Plot trajectories from first initial condition (solid lines)
plot(t1, x1, '-', 'Color', c1, 'LineWidth', 4); 
plot(t1, y1, '-', 'Color', c2, 'LineWidth', 4);
plot(t1, z1, '-', 'Color', c3, 'LineWidth', 4);

% Plot trajectories from second initial condition (dashed lines)
plot(t2, x2, '--', 'Color', c1, 'LineWidth', 4); 
plot(t2, y2, '--', 'Color', c2, 'LineWidth', 4);
plot(t2, z2, '--', 'Color', c3, 'LineWidth', 4);

%% ============================================================
% Set logarithmic x-axis
%% ============================================================
set(gca, 'XScale', 'log');
xlim([1e-1 max(t1)]);
ylim([0 1]);

%% ============================================================
% Axis labels and formatting
%% ============================================================
xlabel('Time', 'FontSize', 26, 'Interpreter', 'latex');
ylabel('Proportion of strategies', 'FontSize', 26, 'FontAngle', 'italic', 'Interpreter', 'latex');

ax = gca;
set(ax, 'FontSize', 26);
box on;  
ax.LineWidth = 2;  

xticks([1e0 1e2 1e4 1e6]);
yticks(0:0.2:1);

% Remove secondary axes labels if they exist
if isprop(ax, 'XAxis') && isprop(ax.XAxis, 'SecondaryLabel')
    ax.XAxis.SecondaryLabel.Visible = 'off'; 
    ax.YAxis.SecondaryLabel.Visible = 'off';  
end

% Ensure tick labels and axes locations are standard
set(ax, 'XTickLabelMode', 'auto', 'YTickLabelMode', 'auto'); 
set(ax, 'XAxisLocation', 'bottom', 'YAxisLocation', 'left'); 

grid off;
hold off;

%% ============================================================
% Dynamics function defining the ODE system
%% ============================================================
function dstate_dt = dynamics(~, state, c, b, alpha, lambda, eta, gamma)
omega=0.01;  % scaling parameter for replicator dynamics
    % Constrain state variables to [0,1]
    x = max(0, min(1, state(1)));
    y = max(0, min(1, state(2)));
    z = max(0, min(1, state(3)));

    % Payoffs for strong and weak cooperators/defectors
    PD1 = (b/2)*eta*x + gamma*(b/(1+lambda))*(1 - eta)*y;
    PH1 = b*eta*x + ((b - c)/2)*eta*(1 - x) + gamma*(b*(1 - eta)*y + ((b/(1+lambda)) - ((lambda*c)/(1+lambda)))*(1 - eta)*(1 - y));
    PD2 = (b/2)*(1 - eta)*y + gamma*((lambda*b)/(1+lambda))*eta*x;
    PH2 = (b*(1 - eta)*y + ((b - c)/2)*(1 - eta)*(1 - y)) + gamma*(b*eta*x + (((lambda*b)/(1+lambda)) - (c/(1+lambda)))*eta*(1 - x));
    
    % Modified payoffs including α effect
    FD1 = PD1;
    FH1 = PH1*(1 - z) + (PH1 - alpha)*z;
    FD2 = PD2;
    FH2 = PH2*(1 - z) + (PH2 - alpha)*z;
    
    % Global fitness terms
    FI = eta^2 * (b - (1 - x)^2 * c) + (1 - eta)^2 * (b - (1 - y)^2 * c) + ...
    2 * gamma * eta * (1 - eta) * (b - (1 - x) * (1 - y) * c);
   
    FM = eta^2 * (b - (1 - x)^2 * c - 2 * alpha * (1 - x)) + ...
    (1 - eta)^2 * (b - (1 - y)^2 * c - 2 * alpha * (1 - y)) + ...
    2 * gamma * eta * (1 - eta) * (b - (1 - x) * (1 - y) * c - alpha * (2 - x - y));
    
    % Compute average payoffs
    aver1 = x*FD1 + (1 - x)*FH1;
    aver2 = y*FD2 + (1 - y)*FH2;
    aver3 = (1 - z)*FI + z*FM;
    
    % Replicator-like dynamics for x, y, z
    FX = omega/2*x*(FD1 - aver1);
    FY = omega/2*y*(FD2 - aver2);
    FZ = omega/2*z*(FM - aver3);
    
    dstate_dt = [FX; FY; FZ];
end
