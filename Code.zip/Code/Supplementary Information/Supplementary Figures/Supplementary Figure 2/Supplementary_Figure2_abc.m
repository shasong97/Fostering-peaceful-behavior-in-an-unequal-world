clc; clear; close all;

%% ============================================================
% Set model parameters
%% ============================================================
c = 1;          % cost 
b = 0.5;        % benefit
gamma = 0.8;    % interaction intensity between types
alpha = 0.8;    % intervention intensity
tspan = [0.1, 1000]; % time span for ODE integration
threshold = 0.99;    % threshold for identifying convergence to (1,1,z)

%% ============================================================
% Define parameter ranges for η and λ
%% ============================================================
eta_list = 0.05:0.05:0.95;      % proportion of strong individuals
lambda_list = 0:0.05:1;         % relative strength ratio

%% ============================================================
% Generate initial conditions grid for x, y, z
%% ============================================================
N = 50;                          % number of points along each dimension
epsilon = 1e-3;                  % small offset to avoid exact 0 or 1
[x0, y0, z0] = ndgrid(linspace(epsilon, 1-epsilon, N), ...
                      linspace(epsilon, 1-epsilon, N), ...
                      linspace(epsilon, 1-epsilon, N));
initial_conditions_set = [x0(:), y0(:), z0(:)]; % flatten to list
total_ic = size(initial_conditions_set, 1);    % total number of initial conditions

%% ============================================================
% Initialize matrix to store fraction of attraction basin
%% ============================================================
vol_frac_matrix = zeros(length(eta_list), length(lambda_list));

%% ============================================================
% Loop over all η and λ combinations
%% ============================================================
for i = 1:length(eta_list)
    eta = eta_list(i);
    for j = 1:length(lambda_list)
        lambda = lambda_list(j);
        count = 0; % counter for ICs reaching target equilibrium

        %% ====================================================
        % Integrate dynamics for all initial conditions
        %% ====================================================
        for ic = 1:total_ic
            init = initial_conditions_set(ic, :)';
            [~, sol] = ode45(@(t, state) dynamics_alpha(t, state, c, b, alpha, lambda, eta, gamma), ...
                             tspan, init);
            final_state = sol(end, :);
            % Check if x and y components exceed threshold
            if final_state(1) >= threshold && final_state(2) >= threshold
                count = count + 1;
            end
        end

        % Store fraction of ICs reaching target equilibrium
        vol_frac_matrix(i, j) = count / total_ic;
        fprintf('η=%.2f, λ=%.2f, fraction=%.3f\n', eta, lambda, vol_frac_matrix(i,j));
    end
end

%% ============================================================
% Remove very small values for visualization
%% ============================================================
vol_frac_matrix(vol_frac_matrix < 0.003) = 0;

%% ============================================================
% Interpolation setup for finer grid
%% ============================================================
eta_fine = 0.001:0.001:0.999;   
lambda_fine = 0:0.001:1;     

[ETA, LAMBDA] = meshgrid(eta_list, lambda_list);
[ETA_fine, LAMBDA_fine] = meshgrid(eta_fine, lambda_fine);

% Interpolate attraction basin fraction on fine grid using spline
vol_frac_interp = interp2(ETA, LAMBDA, vol_frac_matrix', ETA_fine, LAMBDA_fine, 'spline');

%% ============================================================
% Plot attraction basin size as heatmap
%% ============================================================
figure('Position', [100, 100, 580, 500]);
imagesc(eta_fine, lambda_fine, vol_frac_interp);
set(gca, 'YDir', 'normal'); % correct orientation
colormap(sky);               % custom colormap
cb = colorbar; 
cb.Label.Interpreter = 'latex';
cb.Label.String = {'Size of the attraction basin',' for equilibrium $(1,1,\tilde{z})$'}; 
cb.Label.FontSize = 25; 
caxis([0, max(vol_frac_interp(:))]);
xlabel('Proportion of the strong, $\eta$', 'Interpreter', 'latex', 'FontSize', 26);
ylabel('Relative strength ratio, $\lambda$', 'Interpreter', 'latex', 'FontSize', 26);
xlim([0 1]); ylim([0 1]);
set(gca, 'FontSize', 26, 'LineWidth', 1.5);

%% ============================================================
% Define the dynamics function for α-modified system
%% ============================================================
function dstate_dt = dynamics_alpha(~, state, c, b, alpha, lambda, eta, gamma)
    % Constrain state variables to [0,1]
    x = max(0, min(1, state(1))); 
    y = max(0, min(1, state(2))); 
    z = max(0, min(1, state(3)));

    % Payoffs for strong and weak cooperators/defectors
    PD1 = (b/2)*eta*x + gamma*(b/(1+lambda))*(1 - eta)*y;
    PH1 = b*eta*x + ((b - c)/2)*eta*(1 - x) + gamma*(b*(1 - eta)*y + ((b/(1+lambda)) - ((lambda*c)/(1+lambda)))*(1 - eta)*(1 - y));
    PD2 = (b/2)*(1 - eta)*y + gamma*((lambda*b)/(1+lambda))*eta*x;
    PH2 = (b*(1 - eta)*y + ((b - c)/2)*(1 - eta)*(1 - y)) + gamma*(b*eta*x + (((lambda*b)/(1+lambda)) - (c/(1+lambda)))*eta*(1 - x));

    % Modified payoffs including α effect
    FD1 = PD1;
    FH1 = PH1*(1 - z) + (PH1 - alpha)*z;
    FD2 = PD2;
    FH2 = PH2*(1 - z) + (PH2 - alpha)*z;

    % Global fitness terms
    FI = eta^2 * (b - (1 - x)^2 * c) + (1 - eta)^2 * (b - (1 - y)^2 * c) + 2 * gamma * eta * (1 - eta) * (b - (1 - x) * (1 - y) * c);
    FM = eta^2 * (b - (1 - x)^2 * c - 2 * alpha * (1 - x)) + ...
         (1 - eta)^2 * (b - (1 - y)^2 * c - 2 * alpha * (1 - y)) + ...
         2 * gamma * eta * (1 - eta) * (b - (1 - x) * (1 - y) * c - alpha * (2 - x - y));

    % Compute average payoffs
    aver1 = x*FD1 + (1 - x)*FH1;
    aver2 = y*FD2 + (1 - y)*FH2;
    aver3 = (1 - z)*FI + z*FM;

    % Replicator-like dynamics for x, y, z
    dstate_dt = [x*(FD1 - aver1); y*(FD2 - aver2); z*(FM - aver3)];
end
