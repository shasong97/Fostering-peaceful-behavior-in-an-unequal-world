clc; clear; close all;

%% ============================================================
% Set model parameters
%% ============================================================
c = 1;          % cost 
b = 0.5;        % benefit 
gamma = 2;      % interaction intensity between strong and weak types

%% ============================================================
% Define the parameter grids for eta and lambda
%% ============================================================
eta_values = linspace(0.01, 0.99, 50);     % proportion of strong individuals
lambda_values = linspace(0.01, 0.99, 50);  % relative strength ratio of strong to weak

%% ============================================================
% Initialize matrices to store results
%% ============================================================
P_C = zeros(length(eta_values), length(lambda_values));  % overall cooperation level
x = zeros(length(eta_values), length(lambda_values));   % final x (strong) values
y = zeros(length(eta_values), length(lambda_values));   % final y (weak) values

%% ============================================================
% Initial conditions and integration time
%% ============================================================
initial_conditions = [0.5; 0.5];  % initial proportion of dove strategy for strong and weak
tspan = [0 2000];                 % integration time span

%% ============================================================
% Loop over all combinations of eta and lambda
%% ============================================================
for i = 1:length(eta_values)
    for j = 1:length(lambda_values)
        eta = eta_values(i);       % current proportion of strong individuals
        lambda = lambda_values(j); % current relative strength ratio

        % Integrate ODE system
        [~, sol] = ode45(@(t, state) dynamics(t, state, c, b, lambda, eta, gamma), tspan, initial_conditions);

        % Record final state values
        x_final = sol(end, 1);  
        y_final = sol(end, 2);  
        P_C(i,j) = eta * x_final + (1 - eta) * y_final;  % weighted average cooperation
        x(i,j) = x_final;   % store final x value
        y(i,j) = y_final;   % store final y value
    end
end

%% ============================================================
% Plot the results as heatmaps
%% ============================================================
figure('Position', [100, 100, 900, 380]);
colormap(sky);

% Plot heatmap of x (strong) final values
subplot(1,2,1);
imagesc(eta_values, lambda_values, x');
colorbar;
xlabel(['Proportion of the strong, ', '$\eta$'], 'FontSize', 26, 'Interpreter', 'latex');
ylabel(['Relative strength ratio,',' $\lambda$'], 'FontSize', 26, 'Interpreter', 'latex');
title('$x$ (Strong)', 'FontSize', 26, 'Interpreter', 'latex');
axis xy;  % ensure correct axis orientation
set(gca, 'FontSize', 30);

% Plot heatmap of y (weak) final values
subplot(1,2,2);
imagesc(eta_values, lambda_values, y');
colorbar;
xlabel(['Proportion of the strong, ', '$\eta$'], 'FontSize', 26, 'Interpreter', 'latex');
ylabel(['Relative strength ratio,',' $\lambda$'], 'FontSize', 26, 'Interpreter', 'latex');
title('$y$ (Weak)', 'FontSize', 26, 'Interpreter', 'latex');
axis xy;  % ensure correct axis orientation
set(gca, 'FontSize', 30);

%% ============================================================
% Function defining the population dynamics (ODE system)
%% ============================================================
function dstate_dt = dynamics(~, state, c, b, lambda, eta, gamma)
    % Extract current state
    x = state(1);  % proportion of dove strategy for strong individuals
    y = state(2);  % proportion of dove strategy for weak individuals
    
    % Payoffs for strong defectors (PD1) and hawks (PH1)
    PD1 = (b/2)*eta*x + gamma*(b/(1+lambda))*(1 - eta)*y;
    PH1 = b*eta*x + ((b - c)/2)*eta*(1 - x) + gamma*(b*(1 - eta)*y + ((b/(1+lambda)) - ((lambda*c)/(1+lambda)))*(1 - eta)*(1 - y));
    
    % Payoffs for weak defectors (PD2) and hawks (PH2)
    PD2 = (b/2)*(1 - eta)*y + gamma*((lambda*b)/(1+lambda))*eta*x;
    PH2 = (b*(1 - eta)*y + ((b - c)/2)*(1 - eta)*(1 - y)) + gamma*(b*eta*x + (((lambda*b)/(1+lambda)) - (c/(1+lambda)))*eta*(1 - x));
    
    % Compute average payoff for replicator dynamics
    aver1 = x*PD1 + (1 - x)*PH1;
    aver2 = y*PD2 + (1 - y)*PH2;
    
    % Replicator equations for x and y
    FX = x*(PD1 - aver1);
    FY = y*(PD2 - aver2);
    
    % Return derivative of state
    dstate_dt = [FX; FY];
end
