clc; clear; close all;

%% ============================================================
% Set model parameters
%% ============================================================
c = 1;          % cost 
b = 0.5;        % benefit 
eta = 0.5;      % proportion of strong individuals in the population
lambda = 0.5;   % relative strength ratio between strong and weak types

%% ============================================================
% Define range of interaction intensity gamma
%% ============================================================
gamma_values = linspace(0, 3, 100);  % gamma spans from 0 to 3

%% ============================================================
% Initial conditions for the ODE system
%% ============================================================
initial_conditions = [0.5; 0.5];  % initial proportion of dove strategy for strong (x) and weak (y)
tspan = [0 2000];                 % integration time span

%% ============================================================
% Initialize vectors to store final values
%% ============================================================
x_final = zeros(size(gamma_values));  % final x values (strong)
y_final = zeros(size(gamma_values));  % final y values (weak)
F_final = zeros(size(gamma_values));  % weighted average of population strategies

%% ============================================================
% Loop over all gamma values, integrate the dynamics
%% ============================================================
for k = 1:length(gamma_values)
    gamma = gamma_values(k);  % current interaction intensity

    % Integrate ODE system
    [~, sol] = ode45(@(t, state) dynamics(t, state, c, b, lambda, eta, gamma), ...
                     tspan, initial_conditions);

    % Record final proportions
    x_final(k) = sol(end, 1);
    y_final(k) = sol(end, 2);

    % Compute weighted average strategy in population
    F_final(k) = eta*x_final(k) + (1 - eta)*y_final(k);
end

%% ============================================================
% Plot the final strategy proportions as a function of gamma
%% ============================================================
figure('Position', [100, 100, 400, 400]); hold on;

% Plot x (strong) with dashed line
plot(gamma_values, x_final, 'LineWidth', 3, 'Color', [0.2 0.5 0.8], 'LineStyle', '--', 'DisplayName', '$x$ (Strong)');

% Plot y (weak) with solid line
plot(gamma_values, y_final, 'LineWidth', 3, 'Color', [0.9 0.4 0.2], 'LineStyle', '-', 'DisplayName', '$y$ (Weak)');

% Set labels and legend
xlabel({'Interaction intensity, $\gamma$'}, 'FontSize', 18, 'Interpreter', 'latex');
ylabel('Proportion of dove strategy', 'FontSize', 18, 'Interpreter', 'latex');
legend('Interpreter', 'latex', 'FontSize', 16, 'Location', 'best');

% Format axes
box on;
ax = gca;
ax.LineWidth = 2;
set(gca, 'FontSize', 16);

%% ============================================================
% Function defining the population dynamics (ODE system)
%% ============================================================
function dstate_dt = dynamics(~, state, c, b, lambda, eta, gamma)
    % Extract current state
    x = state(1);  % proportion of dove strategy for strong individuals
    y = state(2);  % proportion of dove strategy for weak individuals
    
    % Payoff for strong defectors (PD1) and strong hawks (PH1)
    PD1 = (b/2)*eta*x + gamma*(b/(1+lambda))*(1 - eta)*y;
    PH1 = b*eta*x + ((b - c)/2)*eta*(1 - x) + gamma*(b*(1 - eta)*y + ((b/(1+lambda)) - ((lambda*c)/(1+lambda)))*(1 - eta)*(1 - y));
    
    % Payoff for weak defectors (PD2) and weak hawks (PH2)
    PD2 = (b/2)*(1 - eta)*y + gamma*((lambda*b)/(1+lambda))*eta*x;
    PH2 = (b*(1 - eta)*y + ((b - c)/2)*(1 - eta)*(1 - y)) + gamma*(b*eta*x + (((lambda*b)/(1+lambda)) - (c/(1+lambda)))*eta*(1 - x));
    
    % Average payoffs for replicator dynamics
    aver1 = x*PD1 + (1 - x)*PH1;
    aver2 = y*PD2 + (1 - y)*PH2;
    
    % Replicator equations for x and y
    FX = x*(PD1 - aver1);
    FY = y*(PD2 - aver2);
    
    % Return derivative of state
    dstate_dt = [FX; FY];
end
