clc; clear; close all

%% ============================================================
% Set model parameters
%% ============================================================
b = 0.5;        % benefit 
c = 1;          % cost 
lambda = 0.25;  % relative strength ratio of strong to weak
eta = 0.5;      % proportion of strong individuals
omega = 2;      % scaling factor for replicator dynamics

%% ============================================================
% Define the vector field function for the replicator dynamics
%% ============================================================
f = @(t,XY) [
    % Dynamics for x (proportion of dove among strong)
    (omega/2)*(1-eta)*XY(1)*(1-XY(1)) * ( -(lambda*b)/(1+lambda)*XY(2) - ((b - lambda*c)/(1+lambda))*(1-XY(2)) );
    % Dynamics for y (proportion of dove among weak)
    (omega/2)*eta*XY(2)*(1-XY(2)) * ( -(b/(1+lambda))*XY(1) - ((lambda*b - c)/(1+lambda))*(1-XY(1)) )
];

%% ============================================================
% Create a grid of points over [0,1]x[0,1] for plotting vector field
%% ============================================================
[xGrid,yGrid] = meshgrid(linspace(0,1,20), linspace(0,1,20));

% Initialize arrays for vector components
u = zeros(size(xGrid));  % x-component of vector
v = zeros(size(yGrid));  % y-component of vector

%% ============================================================
% Evaluate vector field at each grid point
%% ============================================================
for i = 1:numel(xGrid)
    XYdot = f(0,[xGrid(i);yGrid(i)]);  % compute derivatives at current point
    u(i) = XYdot(1);  % store x-component
    v(i) = XYdot(2);  % store y-component
end

%% ============================================================
% Normalize vectors for better quiver visualization
%% ============================================================
L = sqrt(u.^2 + v.^2);  % magnitude of vectors
L(L==0) = 1;             % avoid division by zero
u = u ./ L;               % normalize x-component
v = v ./ L;               % normalize y-component

%% ============================================================
% Plot the normalized vector field
%% ============================================================
figure; hold on
quiver(xGrid, yGrid, u, v, 0.5, 'k', 'LineWidth', 1)  % quiver plot, scale factor 0.5, black color

%% ============================================================
% Customize axes and labels
%% ============================================================
ax = gca;
ax.FontSize = 16; 

xlabel({'Proportion of dove strategy', 'among the strong, $x$'}, ...
       'Interpreter','latex','FontSize',17)
ylabel({'Proportion of dove strategy', 'among the weak, $y$'}, ...
       'Interpreter','latex','FontSize',17)

axis([0 1 0 1])  % set axis limits
axis square       % make axis square
box on            % add box around plot

%% ============================================================
% Mark the corners representing extreme strategy states
%% ============================================================
plot(0,0,'ko','MarkerSize',8,'LineWidth',1.5,'MarkerFaceColor','w')  % (0,0) corner, empty circle
plot(1,1,'ko','MarkerSize',8,'LineWidth',1.5,'MarkerFaceColor','w')  % (1,1) corner, empty circle
plot(1,0,'ko','MarkerSize',8,'LineWidth',1.5,'MarkerFaceColor','w')  % (1,0) corner, empty circle
plot(0,1,'ko','MarkerSize',8,'LineWidth',1.5,'MarkerFaceColor','k')  % (0,1) corner, filled black circle
