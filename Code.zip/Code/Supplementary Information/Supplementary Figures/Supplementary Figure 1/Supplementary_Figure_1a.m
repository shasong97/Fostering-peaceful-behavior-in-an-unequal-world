clc; clear; close all;

%% ============================================================
% Set model parameters
%% ============================================================
b = 0.5;           % benefit 
c = 1;             % cost 
gamma = 0.8;       % interaction intensity between types
lambda = 0.1;      % relative strength ratio
omega = 0.01;      % selection intensity for Fermi update
mu = 1e-3;         % mutation rate

%% ============================================================
% Define population sizes
%% ============================================================
Nb_list = 0:300;           % vector of weak individuals
Na_list = [100, 200, 300]; % list of strong individuals

colors = lines(length(Na_list)); % colors for plotting

E_coop_all = zeros(length(Na_list), length(Nb_list)); % store expected cooperation

%% ============================================================
% Loop over each strong group size
%% ============================================================
for idx_na = 1:length(Na_list)
    N_a = Na_list(idx_na);
    E_coop = zeros(size(Nb_list)); % initialize expected cooperation vector

    %% Loop over each weak group size
    for idx_nb = 1:length(Nb_list)
        N_b = Nb_list(idx_nb);
        N = N_a + N_b;  % total population
        if N == 0
            E_coop(idx_nb) = 0;
            continue;
        end

        %% Initialize transition matrix for Markov chain
        num_states = (N_a + 1) * (N_b + 1); 
        P = sparse(num_states, num_states);

        %% Loop over all possible numbers of cooperators in each group
        for i = 0:N_a  
            for j = 0:N_b  
                s = i*(N_b + 1) + j + 1; % state index

                %% Compute payoffs for each strategy
                if N == 1  
                    U_aC = 0; U_aD = 0; U_bC = 0; U_bD = 0; % trivial case
                else
                    % Payoff for cooperators and defectors in strong group
                    U_aC = ((i-1)/(N-1))*(b/2) + gamma*(j/(N-1))*(b/(1+lambda));
                    term1 = (i/(N-1))*b;
                    term2 = ((N_a - i - 1)/(N-1))*((b - c)/2);
                    term3 = gamma * ( (j/(N-1))*b + ((N_b - j)/(N-1))*((b - lambda*c)/(1+lambda)) );
                    U_aD = term1 + term2 + term3;

                    % Payoff for cooperators and defectors in weak group
                    if N_b > 0
                        U_bC = ((j-1)/(N-1))*(b/2) + gamma*(i/(N-1))*(lambda*b/(1+lambda));
                        term1_b = (j/(N-1))*b;
                        term2_b = ((N_b - j - 1)/(N-1))*((b - c)/2);
                        term3_b = gamma * ( (i/(N-1))*b + ((N_a - i)/(N-1))*((lambda*b - c)/(1+lambda)) );
                        U_bD = term1_b + term2_b + term3_b;
                    else
                        U_bC = 0; U_bD = 0; % no weak individuals
                    end
                end

                %% Compute transition probabilities for strong group
                T_plus_a = 0; T_minus_a = 0;
                if N_a > 0
                    factor_a = (i / N_a) * ((N_a - i) / N_a);
                    T_plus_a = factor_a * 1/(1 + exp(-omega*(U_aC - U_aD)));
                    T_minus_a = factor_a * 1/(1 + exp(-omega*(U_aD - U_aC)));
                    % Include mutation
                    T_plus_a = (1 - mu)*T_plus_a + mu*((N_a - i)/N_a);
                    T_minus_a = (1 - mu)*T_minus_a + mu*(i/N_a);
                end

                %% Compute transition probabilities for weak group
                T_plus_b = 0; T_minus_b = 0;
                if N_b > 0
                    factor_b = (j / N_b) * ((N_b - j) / N_b);
                    T_plus_b = factor_b * 1/(1 + exp(-omega*(U_bC - U_bD)));
                    T_minus_b = factor_b * 1/(1 + exp(-omega*(U_bD - U_bC)));
                    % Include mutation
                    T_plus_b = (1 - mu)*T_plus_b + mu*((N_b - j)/N_b);
                    T_minus_b = (1 - mu)*T_minus_b + mu*(j/N_b);
                end

                %% Fill transition matrix P
                total_trans = 0; % sum of outgoing probabilities

                % Strong group: i -> i+1
                if i < N_a
                    s_next = (i+1)*(N_b + 1) + j + 1;
                    P(s, s_next) = T_plus_a;
                    total_trans = total_trans + T_plus_a;
                end

                % Strong group: i -> i-1
                if i > 0
                    s_next = (i-1)*(N_b + 1) + j + 1;
                    P(s, s_next) = T_minus_a;
                    total_trans = total_trans + T_minus_a;
                end

                % Weak group: j -> j+1
                if j < N_b && N_b > 0
                    s_next = i*(N_b + 1) + (j+1) + 1;
                    P(s, s_next) = T_plus_b;
                    total_trans = total_trans + T_plus_b;
                end

                % Weak group: j -> j-1
                if j > 0 && N_b > 0
                    s_next = i*(N_b + 1) + (j-1) + 1;
                    P(s, s_next) = T_minus_b;
                    total_trans = total_trans + T_minus_b;
                end

                % Diagonal entry: probability to stay in the same state
                P(s, s) = 1 - total_trans;
            end
        end

        %% Compute stationary distribution
        [V, ~] = eigs(P.', 1, 1); 
        pi_vec = real(V);          % ensure real values
        pi_vec = pi_vec / sum(pi_vec); % normalize to sum 1

        %% Compute expected cooperation
        E_coop_val = 0;
        for i = 0:N_a
            for j = 0:N_b
                s = i*(N_b + 1) + j + 1; % state index
                ratio = (i + j) / N;     % fraction of cooperators
                E_coop_val = E_coop_val + pi_vec(s) * ratio;
            end
        end
        E_coop(idx_nb) = E_coop_val;
    end

    %% Store results for current Na
    E_coop_all(idx_na,:) = E_coop;
end

%% ============================================================
% Plot expected cooperation as function of weak population size
%% ============================================================
figure('Position',[100 100 670 600]); hold on; 
for idx_na = 1:length(Na_list)
    plot(Nb_list, E_coop_all(idx_na,:), 'LineWidth',3, 'Color',colors(idx_na,:), ...
        'DisplayName', sprintf('$N_a$ = %d', Na_list(idx_na)));
end

xlabel('Number of weak individuals, $N_b$','FontSize',23, 'Interpreter', 'latex');
ylabel({'Expected proportion of dove', 'strategies, $\langle \hat{F}_{\mathrm{Dove}} \rangle$'},'FontSize',23, 'Interpreter', 'latex');
ytickformat('%.3f') % format y-axis
legend('Location','best','FontSize',23, 'Interpreter', 'latex');
set(gca, 'FontSize', 23);
ax = gca;
ax.LineWidth = 1.5;      
box on;
