clc; clear; close all;

%% ============================================================
% Set population and game parameters
%% ============================================================
N_a = 100;       % number of strong individuals
N_b = 300;       % number of weak individuals
b = 0.5;         % benefit 
c = 1;           % cost 
gamma = 0.8;     % interaction intensity between types
lambda = 0.1;    % relative strength ratio
omega = 0.01;    % selection intensity in Fermi update
mu = 1e-3;       % mutation rate

%% ============================================================
% Generate all possible states and index mapping
%% ============================================================
[i_states, j_states] = meshgrid(0:N_a, 0:N_b); % meshgrid of cooperators
states = [i_states(:), j_states(:)];           % flatten states into list
num_states = size(states,1);                   % total number of states

% Map (i,j) to state index
state2idx = zeros(N_a+1, N_b+1);  
for s = 1:num_states
    i = states(s,1);
    j = states(s,2);
    state2idx(i+1, j+1) = s;  % linear index mapping
end

%% ============================================================
% Initialize transition matrix
%% ============================================================
P = zeros(num_states);

% Extract i and j for all states
i_all = states(:,1);
j_all = states(:,2);
N = N_a + N_b;
N_minus_1 = N - 1;

%% ============================================================
% Compute payoffs for all states
%% ============================================================
x_a = i_all / N_a; % fraction of strong cooperators
x_b = j_all / N_b; % fraction of weak cooperators

% Strong cooperators payoff
term1_aC = (i_all - 1) ./ N_minus_1 .* (b/2);
term2_aC = gamma * j_all ./ N_minus_1 .* (b/(1+lambda));
U_aC = term1_aC + term2_aC;
U_aC(i_all == 0) = 0; % handle edge case

% Strong defectors payoff
term1_aD = i_all ./ N_minus_1 .* b;
term2_aD = (N_a - i_all - 1) ./ N_minus_1 .* ((b - c)/2);
term3_aD = gamma * (j_all ./ N_minus_1 .* b + (N_b - j_all) ./ N_minus_1 .* ((b - lambda*c)/(1 + lambda)));
U_aD = term1_aD + term2_aD + term3_aD;
U_aD(i_all == N_a) = 0; % handle edge case

% Weak cooperators payoff
term1_bC = (j_all - 1) ./ N_minus_1 .* (b/2);
term2_bC = gamma * i_all ./ N_minus_1 .* (lambda*b/(1 + lambda));
U_bC = term1_bC + term2_bC;
U_bC(j_all == 0) = 0; % handle edge case

% Weak defectors payoff
term1_bD = j_all ./ N_minus_1 .* b;
term2_bD = (N_b - j_all - 1) ./ N_minus_1 .* ((b - c)/2);
term3_bD = gamma * (i_all ./ N_minus_1 .* b + (N_a - i_all) ./ N_minus_1 .* ((lambda*b - c)/(1 + lambda)));
U_bD = term1_bD + term2_bD + term3_bD;
U_bD(j_all == N_b) = 0; % handle edge case

%% ============================================================
% Compute Fermi transition probabilities for all states
%% ============================================================
T_plus_a = ((N_a - i_all) ./ N_a) .* (i_all ./ N_a) .* (1 ./ (1 + exp(-omega*(U_aC - U_aD))));
T_minus_a = (i_all ./ N_a) .* ((N_a - i_all) ./ N_a) .* (1 ./ (1 + exp(-omega*(U_aD - U_aC))));

T_plus_b = ((N_b - j_all) ./ N_b) .* (j_all ./ N_b) .* (1 ./ (1 + exp(-omega*(U_bC - U_bD))));
T_minus_b = (j_all ./ N_b) .* ((N_b - j_all) ./ N_b) .* (1 ./ (1 + exp(-omega*(U_bD - U_bC))));

% Include mutation effects
T_plus_a = (1 - mu)*T_plus_a + mu*(N_a - i_all)/N_a;
T_minus_a = (1 - mu)*T_minus_a + mu*(i_all/N_a);
T_plus_b = (1 - mu)*T_plus_b + mu*(N_b - j_all)/N_b;
T_minus_b = (1 - mu)*T_minus_b + mu*(j_all/N_b);

%% ============================================================
% Fill transition matrix P
%% ============================================================
for s = 1:num_states
    i = i_all(s);
    j = j_all(s);

    if i < N_a
        s_next = state2idx(i+2, j+1); % next state if strong cooperator increases
        P(s, s_next) = T_plus_a(s);
    end

    if i > 0
        s_next = state2idx(i, j+1);  % next state if strong cooperator decreases
        P(s, s_next) = P(s, s_next) + T_minus_a(s);
    end

    if j < N_b
        s_next = state2idx(i+1, j+2); % next state if weak cooperator increases
        P(s, s_next) = P(s, s_next) + T_plus_b(s);
    end

    if j > 0
        s_next = state2idx(i+1, j);  % next state if weak cooperator decreases
        P(s, s_next) = P(s, s_next) + T_minus_b(s);
    end

    % Diagonal entry: probability to remain in same state
    P(s, s) = 1 - sum(P(s, :));
end

%% ============================================================
% Compute stationary distribution
%% ============================================================
[V, D] = eig(P.'); % eigen decomposition
[~, idx] = min(abs(diag(D) - 1)); % find eigenvalue closest to 1
pi_vec = V(:, idx);                % corresponding eigenvector
pi_vec = real(pi_vec) / sum(real(pi_vec)); % normalize

%% ============================================================
% Compute probability distribution of overall fraction of doves
%% ============================================================
ratio = (i_all + j_all) / N;              % fraction of cooperators in each state
[unique_ratio, ~, idx_ratio] = unique(ratio);
prob_ratio = accumarray(idx_ratio, pi_vec); % sum probabilities for same ratio

%% ============================================================
% Plot probability distribution of dove proportion
%% ============================================================
figure('Position',[100 100 600 600]);
plot(unique_ratio, prob_ratio, 'LineWidth',3);
xlabel('Proportion of dove strategies, $\hat{F}_{\mathrm{Dove}}$','FontSize',23, 'Interpreter', 'latex');
ylabel('Probability, $P$','FontSize',23, 'Interpreter', 'latex');
set(gca, 'FontSize', 23);
ax = gca;
ax.LineWidth = 1.5;        
box on;

disp(['Sum of stationary distribution = ', num2str(sum(pi_vec), '%.6f')]);

%% ============================================================
% Plot filled area for probability distribution
%% ============================================================
figure('Position',[100 100 600 600]);

[unique_ratio_sorted, sort_idx] = sort(unique_ratio);
prob_ratio_sorted = prob_ratio(sort_idx);

area(unique_ratio_sorted, prob_ratio_sorted, 'FaceColor', [0.7 1 0.7], 'FaceAlpha', 0.4, 'EdgeColor', 'none');
hold on;

plot(unique_ratio_sorted, prob_ratio_sorted, 'LineWidth', 3, 'Color', [0 0.4470 0.7410]);

xlabel('Proportion of dove strategies, $\hat{F}_{\mathrm{Dove}}$', ...
       'FontSize', 23, 'Interpreter', 'latex');
ylabel('Probability, $P$', ...
       'FontSize', 23, 'Interpreter', 'latex');

set(gca, 'FontSize', 23);
ax = gca;
ax.LineWidth = 1.5;  
box on;
hold off;
